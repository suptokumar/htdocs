<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Job It Medical Software</title>
    <link rel="stylesheet" href="<?php echo e(asset('/public/vendor/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('/public/vendor/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/vendor/main.js?'.rand())); ?>"></script>
    <script src="<?php echo e(asset('/public/vendor/admin.js?'.rand())); ?>"></script>
</head>
<body>
    <h2 style="text-align: center; margin: 10px">
    <button class="btn btn-info" style="float: left" onclick="window.location='<?php echo e(url('/')); ?>'">back</button>
            <button class="btn btn-info" style="float: left;" onclick="window.location='<?php echo e(url('/')); ?>'">Menu</button> 

        Emergency
    </h2>
   <div class="parent" style="width: 30%; float: left; border: 1px solid #ccc; margin: 10px; padding: 10px;">
       <form action="<?php echo e(url('/emergency')); ?>" method="POST">
<?php if($message = session("message")): ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
<div class="alert alert-success" role="alert">
<?php echo e($success); ?>

</div>
<?php endif; ?>

<?php if($new_client = session("new_client")): ?>
<div class="alert alert-success" role="alert">
<?php echo e($new_client); ?>

</div>
<?php endif; ?>
<?php echo csrf_field(); ?>

  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label"> Name</label>
    <div class="col-sm-10">
      <input type="text" name="name" autofocus="" autocomplete="off" class="form-control" value="<?php echo e(isset($doctor)?$doctor->name:''); ?>" id="inputEmail3" placeholder=" Name">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Age</label>
    <div class="col-sm-10">
      <input type="text" name="age" class="form-control" autocomplete="off" value="<?php echo e(isset($doctor)?$doctor->age:''); ?>" id="inputPassword3" placeholder="Age">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Contact</label>
    <div class="col-sm-10">
      <input type="text" name="contact" class="form-control" autocomplete="off" value="<?php echo e(isset($doctor)?$doctor->contact:''); ?>" id="inputPassword3" placeholder="contact">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Gender</label>
    <div class="col-sm-10">
      
      <select name="gender" class="form-control" id="inputPassword3">
      	<option value="Male" <?php echo e(isset($doctor)?$doctor->gender:''); ?>>Male</option>
      	<option value="Female" <?php echo e(isset($doctor)?$doctor->gender:''); ?>>Female</option>
      	<option value="Other" <?php echo e(isset($doctor)?$doctor->gender:''); ?>>Others</option>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Village/Road</label>
    <div class="col-sm-10">
      <input type="text" name="village" class="form-control" autocomplete="off" value="<?php echo e(isset($doctor)?$doctor->village:''); ?>" id="inputPassword3" placeholder="Village/Road">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Thana</label>
    <div class="col-sm-10">
      <input type="text" name="thana" class="form-control" autocomplete="off" value="<?php echo e(isset($doctor)?$doctor->thana:''); ?>" id="inputPassword3" placeholder="Thana">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">District</label>
    <div class="col-sm-10">
      <input type="text" name="district" class="form-control" autocomplete="off" value="<?php echo e(isset($doctor)?$doctor->district:''); ?>" id="inputPassword3" placeholder="District">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Date</label>
    <div class="col-sm-10">
      <input type="date" name="date" class="form-control" value="<?php echo e(isset($doctor)?$doctor->contact:''); ?>" id="inputPassword3" placeholder="date">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Time</label>
    <div class="col-sm-10">
      <input type="hidden" name="time" class="form-control" value="<?php echo e(date("Y-m-d H:i:s")); ?>" id="inputPassword3" placeholder="time">
      <h3 class="time"></h3>
      <script>
        setInterval(function(){
          var d = new Date();
          var n = d.toLocaleTimeString();
          document.querySelector(".time").innerHTML = n;
        },1);
      </script>
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Consultant</label>
    <div class="col-sm-10">
      <select name="consultant" class="form-control" id="inputPassword3">
      <option value="" <?php echo e(isset($doctor)?($doctor->consultant==''?'selected':''):''); ?>>--Select--</option>

      	
        <?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      	<option value="<?php echo e($d->name); ?>" <?php echo e(isset($doctor)?($doctor->consultant==$d->name?'selected':''):''); ?>><?php echo e($d->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="refone" class="col-sm-2 col-form-label">Reffered by</label>
    <div class="col-sm-10">
     <input name="reffered" list="browsers" autocomplete="off" class="form-control" id="refone" value="<?php echo e(isset($doctor)?$doctor->reffered:''); ?>">
     <datalist id="browsers">

      <?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($d->name); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </datalist>
    </div>
  </div>


  <div class="form-group row">
    <div class="col-sm-12">
        <input type="hidden" name="id" value="<?php echo e(isset($doctor)?$doctor->id:''); ?>">

      <button type="submit" class="btn btn-success float-right"><?php echo e(!isset($doctor)?'Create':'Update'); ?></button>
    </div>
  </div>
</form>
   </div>
   <div class="parent" style="width: 60%; float: left;">
<div class="search" style="width: 100%; padding: 2%; overflow: hidden">
  <button class="btn btn-info"  onclick="printData()">Print</button>

<div class="rk" style="float: right; align-items: center;">
Search <input type="search" id="snod410" autocomplete="off" onkeyup="emargency(1)" style="padding: 10px; border: 1px solid #ccc; outline: none;" placeholder="Search">
</div>
<div class="dk">
<input type="hidden" value="<?php echo e(csrf_token()); ?>" id="csrf">
</div>
</div>
<div class="all_doctors" style="width: 100%">

</div>
<script>
  function printData()
{
   var divToPrint=document.getElementById("bmw");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML+"<style>table{border-collapse:collapse;} td{border: 1px solid #ccc; padding: 10px; max-width: 10%;}.opt{display:none;}</style>");
   newWin.print();
   newWin.close();
}







</script>
<script>
    $(document).ready(function() {
        emargency(1);
    });
        function dp_fun(page){
        emargency(page);

    }
</script>

   </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\hospital\resources\views/emargency.blade.php ENDPATH**/ ?>