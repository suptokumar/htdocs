<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Job It Medical Software</title>
    <link rel="stylesheet" href="<?php echo e(asset('/public/vendor/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('/public/vendor/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/vendor/main.js?'.rand())); ?>"></script>
    <script src="<?php echo e(asset('/public/vendor/admin.js?'.rand())); ?>"></script>
</head>
<body>
    <h2 style="text-align: center; margin: 10px">
    <button class="btn btn-info" style="float: left" onclick="window.history.back()">back</button>
            <button class="btn btn-info" style="float: left; margin: 5px" onclick="window.location='<?php echo e(url('/')); ?>'">Menu</button> 

        Discharge <?php echo e($user->name); ?>

    </h2>
   <div class="parent" style="width: 30%; float: left; border: 1px solid #ccc; margin: 10px; padding: 10px;">
       <form action="<?php echo e(url('/admission/discharge')); ?>" method="POST">
<?php if($message = session("message")): ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
<div class="alert alert-success" role="alert">
<?php echo e($success); ?>

</div>
<?php endif; ?>

<?php if($new_client = session("new_client")): ?>
<div class="alert alert-success" role="alert">
<?php echo e($new_client); ?>

</div>
<?php endif; ?>
<?php echo csrf_field(); ?>

  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-4 col-form-label"> Total Amount</label>
    <div class="col-sm-8">
      <input type="text" name="total" autofocus="" class="form-control" readonly="" value="<?php echo e($total); ?>" id="inputEmail3" placeholder=" Name">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-4 col-form-label"> Paid Amount</label>
    <div class="col-sm-8">
      <input type="text" name="age" class="form-control" readonly="" value="<?php echo e($paid); ?>" id="inputPassword3" placeholder="Age">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-4 col-form-label">Due Amount</label>
    <div class="col-sm-8">
      <input type="text" name="contact" class="form-control" readonly="" value="<?php echo e($total-$paid); ?>" id="inputPassword3" placeholder="contact">
    </div>
  </div>

  
  <div class="form-group row">
    <div class="col-sm-12">
        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
	
<?php if($total-$paid>0): ?>
      <a type="submit" style="color: white;" class="btn btn-success float-left" href="<?php echo e(url('/admission/collect/')); ?>/<?php echo e($user->id); ?>">Collect Page</a>
<?php endif; ?>
      <button type="submit" class="btn btn-danger float-right">Discharge</button>
    </div>
  </div>
</form>
   </div>
   <div class="parent" style="width: 60%; float: left;">
<div class="search" style="width: 100%; padding: 2%; overflow: hidden">

<div class="rk" style="float: right; align-items: center;">
Search <input type="search" id="snod410" autocomplete="off" onkeyup="prev_details3(1)" style="padding: 10px; border: 1px solid #ccc; outline: none;" placeholder="Search">
</div>
<input type="hidden" value="<?php echo e($user->id); ?>" id="em_id">

<button class="btn btn-danger float-left" onclick="exportTableToExcel('done1','<?php echo e($user->name); ?>')">Download in Excel</button>
<div class="dk">
<input type="hidden" value="<?php echo e(csrf_token()); ?>" id="csrf">
</div>
</div>
<div class="all_doctors" style="width: 100%">

</div>

<script>
    $(document).ready(function() {
        prev_details3(1);
    });
        function dp_fun(page){
        prev_details3(page);

    }
</script>

   </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\hospital\resources\views/adddischarged.blade.php ENDPATH**/ ?>