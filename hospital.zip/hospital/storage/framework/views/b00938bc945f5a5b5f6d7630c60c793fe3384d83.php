<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Job It Medical Software</title>
    <script src="<?php echo e(asset('/public/vendor/jquery.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('/public/vendor/bootstrap.min.css')); ?>">
	<style>
	*{margin: 0;padding: 0;outline: 0;}


.headerlogin{
	 background: #9DCB34AA;
    width: 600px;
    margin: 0 auto;
    margin-top: 120px;
    position: relative;
}
.login{
	position: relative;
	margin: 80px;
	padding:  50px 20px;
}

#log{
	 padding: 11px;
    font-size: 20px;
    color: blue;
    width: 269px;
}
#pass{
	 padding: 11px;
    font-size: 20px;
    color: blue;
}
#username{
	 padding: 11px;
    font-size: 20px;
    color: blue;
}

</style>
</head>
<body style="background: url('<?php echo e(asset('/public/img/1.jpg')); ?>') no-repeat fixed center;">
	<h2 style="font-size: 30px; font-family: cursive;color: blue; text-align:center; background: #ddddddAA; padding: 20px">Hospital Management Software By JOB IT</h2>
	<div class="headerlogin">

		<div class="login">
<form action="<?php echo e(url('/login')); ?>" method="POST">
<?php if($message = session("message")): ?>
  <div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php echo csrf_field(); ?>


	<table>
  
  <tr>
    <td><label for="log" style="font-size: 25px;color: blue; ">Login as:</label></td>
    <td><select id="log" name="log" onchange="reg(this.value)">
  <option value="Reception">Reception</option>
  <option value="Manager">Manager</option>
  <option value="Admin">Admin</option>
  
</select></td>
    
  </tr>
  <tr>
    <td><label for="username" autocomplete="off" style="font-size: 25px;color: blue;">Phone number:</label></td>
    <td><input type="text" id="username" name="login" autocomplete="off" placeholder="Phone number"></td>
    
  </tr>
  <tr class="rec">
    <td><label for="pass" style="font-size: 25px;color: blue; ">Password:</label></td>
    <td><input type="password" id="pass" name="pass" autocomplete="off" placeholder="Password"></td>
  </tr>
  <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr class="admin">
    <td><label for="pass" style="font-size: 25px;color: blue; ">Password:</label></td>
    <td><input type="password" id="pass" name="pass<?php echo e($ad->id); ?>" autocomplete="off" placeholder="Password of <?php echo e($ad->name); ?>"></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <style>
    .admin {
      display: none;
    }
  </style>
<script>
  function reg(v){
    if (v=="Admin") {
      $(".admin").show();
      $(".rec").hide();
    }else{
      $(".admin").hide();
      $(".rec").show();  
    }
  }
</script>
  <tr>
    <td></td>
    <td><input type="submit" value="Login" style="padding: 10px;font-size: 17px;font-weight: bold;"></td>
    
  </tr>
  
</table>
</form>

	</div>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\hospital\resources\views/login.blade.php ENDPATH**/ ?>