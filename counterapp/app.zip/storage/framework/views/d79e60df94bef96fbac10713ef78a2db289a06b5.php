<!DOCTYPE html>
<html lang="en" dir="">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Users - Infinity</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('/public/html/src')); ?>/assets/styles/vendor/datatables.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/public/html/src')); ?>/assets/styles/css/themes/lite-purple.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/public/html/src')); ?>/assets/styles/vendor/perfect-scrollbar.css">
</head>

<body class="text-left">
    <div class="app-admin-wrap layout-sidebar-large clearfix">
        <div class="main-header">
            <div class="logo">
                <img onclick="window.location='<?php echo e(url('/dashboard')); ?>'" src="<?php echo e(url('/public/html/src')); ?>/assets/images/logo.png" alt="">
            </div>

            <div class="menu-toggle">
                <div></div>
                <div></div>
                <div></div>
            </div>

            <div class="d-flex align-items-center">
                <!-- Mega menu -->
                <div class="dropdown  d-none d-md-block">
                    <a href="<?php echo e(url('/')); ?>" target="_blank" class="btn text-muted mr-3" >Visit App</a>

                </div>
                <!-- / Mega menu -->
                <div class="search-bar">
                    <input type="text" placeholder="Search">
                    <i class="search-icon text-muted i-Magnifi-Glass1"></i>
                </div>
            </div>

            <div style="margin: auto"></div>

            <div class="header-part-right">
                <!-- Full screen toggle -->
                <i class="i-Full-Screen header-icon d-none d-sm-inline-block" data-fullscreen></i>
                <!-- Grid menu Dropdown -->
                <div class="dropdown">
                    <i class="i-Safe-Box text-muted header-icon" role="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <div class="menu-icon-grid">
                            <a href="#"><i class="i-Shop-4"></i> Home</a>
                            <a href="#"><i class="i-Library"></i> UI Kits</a>
                            <a href="#"><i class="i-Drop"></i> Apps</a>
                            <a href="#"><i class="i-File-Clipboard-File--Text"></i> Forms</a>
                            <a href="#"><i class="i-Checked-User"></i> Sessions</a>
                            <a href="#"><i class="i-Ambulance"></i> Support</a>
                        </div>
                    </div>
                </div>
                <!-- Notificaiton -->
                <div class="dropdown">
                    <div class="badge-top-container" role="button" id="dropdownNotification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="badge badge-primary">3</span>
                        <i class="i-Bell text-muted header-icon"></i>
                    </div>
                    <!-- Notification dropdown -->
                    <div class="dropdown-menu dropdown-menu-right rtl-ps-none notification-dropdown" aria-labelledby="dropdownNotification" data-perfect-scrollbar data-suppress-scroll-x="true">
                        <div class="dropdown-item d-flex">
                            <div class="notification-icon">
                                <i class="i-Speach-Bubble-6 text-primary mr-1"></i>
                            </div>
                            <div class="notification-details flex-grow-1">
                                <p class="m-0 d-flex align-items-center">
                                    <span>New message</span>
                                    <span class="badge badge-pill badge-primary ml-1 mr-1">new</span>
                                    <span class="flex-grow-1"></span>
                                    <span class="text-small text-muted ml-auto">10 sec ago</span>
                                </p>
                                <p class="text-small text-muted m-0">James: Hey! are you busy?</p>
                            </div>
                        </div>
                        <div class="dropdown-item d-flex">
                            <div class="notification-icon">
                                <i class="i-Receipt-3 text-success mr-1"></i>
                            </div>
                            <div class="notification-details flex-grow-1">
                                <p class="m-0 d-flex align-items-center">
                                    <span>New order received</span>
                                    <span class="badge badge-pill badge-success ml-1 mr-1">new</span>
                                    <span class="flex-grow-1"></span>
                                    <span class="text-small text-muted ml-auto">2 hours ago</span>
                                </p>
                                <p class="text-small text-muted m-0">1 Headphone, 3 iPhone x</p>
                            </div>
                        </div>
                        <div class="dropdown-item d-flex">
                            <div class="notification-icon">
                                <i class="i-Empty-Box text-danger mr-1"></i>
                            </div>
                            <div class="notification-details flex-grow-1">
                                <p class="m-0 d-flex align-items-center">
                                    <span>Product out of stock</span>
                                    <span class="badge badge-pill badge-danger ml-1 mr-1">3</span>
                                    <span class="flex-grow-1"></span>
                                    <span class="text-small text-muted ml-auto">10 hours ago</span>
                                </p>
                                <p class="text-small text-muted m-0">Headphone E67, R98, XL90, Q77</p>
                            </div>
                        </div>
                        <div class="dropdown-item d-flex">
                            <div class="notification-icon">
                                <i class="i-Data-Power text-success mr-1"></i>
                            </div>
                            <div class="notification-details flex-grow-1">
                                <p class="m-0 d-flex align-items-center">
                                    <span>Server Up!</span>
                                    <span class="badge badge-pill badge-success ml-1 mr-1">3</span>
                                    <span class="flex-grow-1"></span>
                                    <span class="text-small text-muted ml-auto">14 hours ago</span>
                                </p>
                                <p class="text-small text-muted m-0">Server rebooted successfully</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Notificaiton End -->

                <!-- User avatar dropdown -->
                <div class="dropdown">
                    <div class="user colalign-self-end">
                        <img src="<?php echo e(url('/public/html/src')); ?>/assets/images/faces/1.jpg" id="userDropdown" alt="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                        
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                            <div class="dropdown-header">
                                <i class="i-Lock-User mr-1"></i> <?php echo e(Auth::user()->name); ?>

                            </div>
                            <a class="dropdown-item" href="<?php echo e(url('/settings')); ?>">Account settings</a>
                            <a class="dropdown-item"  href="<?php echo e(url('/logout')); ?>">Sign out</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="side-content-wrap">
            <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">
                <ul class="navigation-left">

                    <li class="nav-item">
                        <a class="nav-item-hold" href="<?php echo e(url('/records')); ?>">
                            <i class="nav-icon i-File-Horizontal-Text"></i>
                            <span class="nav-text">Records</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-item-hold" href="<?php echo e(url('/users')); ?>">
                            <i class="nav-icon i-Administrator"></i>
                            <span class="nav-text">Users</span>
                        </a>
                        
                    </li>
                    <li class="nav-item">
                        <a class="nav-item-hold" href="<?php echo e(url('/clouds')); ?>">
                            <i class="nav-icon i-Data-Cloud"></i>
                            <span class="nav-text">Json Editor</span>
                        </a>
                    </li>

                </ul>
            </div>

            <div class="sidebar-left-secondary rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">
                <!-- Submenu Dashboards -->
                
            </div>
            <div class="sidebar-overlay"></div>
        </div>
        <!--=============== Left side End ================-->

        <!-- ============ Body content start ============= -->
        <div class="main-content-wrap sidenav-open d-flex flex-column">

            <div class="breadcrumb">
                <h1 class="mr-2">Infinity</h1>
                <ul>
                    <li><a href="<?php echo e(url('/users')); ?>">Users</a></li>
                    <li>Edit user</li>
                </ul>
            </div>
            <div class="separator-breadcrumb border-top"></div>
            <div class="row">
            	<div class="col-2">
            		
<button type="button" class="btn btn-secondary ripple m-1" onclick="window.location='<?php echo e(url('/users')); ?>'">Back</button>
            	</div>
            </div>
            <div class="row">
            	<div class="col-md-12">
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="card-title mb-3"><?php echo e($user->name); ?>'s Information</div>
                            <form action="<?php echo e(url('/edituser')); ?>" method="POST">
<?php if($message = session("message")): ?>
<div class="alert alert-card alert-success" role="alert">
<?php echo e($message); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>

<?php if($success = session("success")): ?>
<div class="alert alert-card alert-success" role="alert">
<?php echo e($success); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
                            	<?php echo csrf_field(); ?>
                            	<input type="hidden" value="<?php echo e($user->id); ?>" name="id">
                                <div class="row">
                                    <div class="col-md-6 form-group mb-3">
                                        <label for="name">Username</label>
                                        <input type="text" value="<?php echo e($user->name); ?>" class="form-control" id="name" name="name" placeholder="Enter your first name">
                                    </div>


                                    <div class="col-md-6 form-group mb-3">
                                        <label for="email">Email address</label>
                                        <input type="email" value="<?php echo e($user->email); ?>" class="form-control" id="email" name="email" placeholder="Enter email">
                                        <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
                                    </div>

                                    <div class="col-md-6 form-group mb-3">
                                        <label for="picker1">Select Role</label>
                                        <select class="form-control" name="role">
                                            <option <?php echo e($user->role=="Admin"?"selected":""); ?> value="Admin">Admin</option>
                                            <option <?php echo e($user->role=="User"?"selected":""); ?> value="User">User</option>
                                        </select>
                                    </div>

                                    <div class="col-md-12">
                                        <button class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <!-- ============ Search UI End ============= -->

    <script src="<?php echo e(url('/public/html/src')); ?>/assets/js/vendor/jquery-3.3.1.min.js"></script>
    <script src="<?php echo e(url('/public/html/src')); ?>/assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(url('/public/html/src')); ?>/assets/js/vendor/perfect-scrollbar.min.js"></script>
    <script src="<?php echo e(url('/public/html/src')); ?>/assets/js/vendor/echarts.min.js"></script>
    <script src="<?php echo e(url('/public/html/src')); ?>/assets/js/vendor/datatables.min.js"></script>

    <script src="<?php echo e(url('/public/html/src')); ?>/assets/js/es5/echart.options.min.js"></script>
    <script src="<?php echo e(url('/public/html/src')); ?>/assets/js/es5/dashboard.v2.script.min.js"></script>

    <script src="<?php echo e(url('/public/html/src')); ?>/assets/js/es5/script.min.js"></script>
    <script src="<?php echo e(url('/public/html/src')); ?>/assets/js/es5/sidebar.large.script.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\counterapp\resources\views/edituser.blade.php ENDPATH**/ ?>