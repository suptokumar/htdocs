
<?php $__env->startSection("title","Create Client | School management software"); ?>
<?php $__env->startSection("active","settings"); ?>
<?php $__env->startSection("content"); ?>
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
}
</style>
 <article>

<form style="width: 90%; margin: 0 auto;" action="<?php echo e(url('/create_client')); ?>" method="POST" enctype="multipart/form-data"><br>
	<h3 style="text-align: center;">Create Client</h3>
			<?php if($message = session("message")): ?>
	<div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
	<div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>

<?php if($new_client = session("new_client")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($new_client); ?>

</div>
<?php endif; ?>

 <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Full Name')); ?></label>
    <input type="text" class="form-control" id="name" name="name"  value="<?php echo e(old("name")); ?>" required aria-describedby="emailHelp" placeholder="Enter Full Name">
  </div>
<input type="hidden" name="id"  value="<?php echo e(Auth::user()->id); ?>">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Email address')); ?></label>
    <input type="email" class="form-control" id="email" required="" name="email" aria-describedby="emailHelp"    value="<?php echo e(old("email")); ?>" placeholder="Enter email">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Phone number')); ?></label>
    <input type="text" class="form-control" id="phone" required="" name="phone" aria-describedby="emailHelp"     value="<?php echo e(old("phone")); ?>" placeholder="Enter phone number">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Hour Rate')); ?></label>
    <input type="number" class="form-control" id="rate" required="" name="rate" aria-describedby="emailHelp" value="<?php echo e(old("rate")); ?>" placeholder="Enter Hourly Rate">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Payment Method')); ?></label>
    <select class="form-control" id="payment" required="" name="payment">
    	<option value="PayPal">PayPal</option>
    	<option value="Ria">Ria</option>
    	<option value="Western Union">Western Union</option>
    	<option value="Bank Account">Bank Account</option>
    	<option value="Others">Others</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Payment Plan')); ?></label>
    <select class="form-control" id="payment_plan" required="" name="payment_plan">
      <option value="Advance">Advance</option>
      <option value="In arrears">In arrears</option>
    </select>
  </div>

 
  <div style="padding: 10px; overflow: hidden">
  <button type="submit" class="btn btn-success" style="float: right;">Save</button>
  </div>
</form>


 </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/create_client.blade.php ENDPATH**/ ?>