<style>
.top_nav a.<?php echo e($home); ?>{
	background: #1e4478;
}
</style>
<div class="fulll_stak_menu">
	<div class="partision">
		<h2 onclick="openNav();" style="cursor: pointer; user-select: none;"><span class="fa fa-bars"></span><img src="<?php echo e(asset('public/img/fev.png')); ?>" alt="" style="height:40px"></h2>
		
	</div>

<div class="partision">
<div class="user_setting">
	<a href="<?php if(Auth::check()): ?>
	<?php echo e(url('/logout')); ?>

	<?php else: ?>
	<?php echo e(url('/login')); ?>

	<?php endif; ?>"><span class="fa fa-user"></span> <span class="wo"><?php if(Auth::check()): ?>
	<?php echo e(__('Logout')); ?>

	<?php else: ?>
	<?php echo e(__('Login')); ?>

	<?php endif; ?></span></a>
</div>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="<?php echo e(url("/")); ?>">Home</a>
  <a href="<?php echo e(url("/add_member")); ?>">Add Member</a>
  <a href="<?php echo e(url("/add_month")); ?>">Add Monthly Fees</a>
  <a href="<?php echo e(url("/user_payment")); ?>">User Payment</a>
  <a href="<?php echo e(url("/external")); ?>">External Fees</a>
  <a href="<?php echo e(url("/expense")); ?>">Expense</a>
  <a href="<?php echo e(url("/reports")); ?>">Reports</a>
</div>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "white";
}
</script>
</div>
</div><?php /**PATH C:\xampp\htdocs\proti\resources\views/layout/header.blade.php ENDPATH**/ ?>