<style>
.top_nav a.<?php echo e($home); ?>{
	background: #1e4478;
}
</style>
<div class="top_nav">
<div>
<?php if(Auth::check() && Auth::user()->role=='Admin'): ?>
<a class="dashboard" href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
<?php else: ?>
<a class="deals" href="<?php echo e(url('/deals')); ?>"><?php echo e(__('Best Deals')); ?></a>
<?php endif; ?>
</div>
<ul>
  <li><a class="home" href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a></li>

  <li><a class="shop" href="<?php echo e(url('/shop')); ?>"><?php echo e(__('Shop')); ?></a></li>
  <li><a class="contact" href="<?php echo e(url('/contact')); ?>"><?php echo e(__('Contact')); ?></a></li>
  <li><a class="about" href="<?php echo e(url('/about')); ?>"><?php echo e(__('About us')); ?></a></li>
  <li><a class="login" href="Javascript:void(0)"><?php echo e(__('Language')); ?> <span class="glyphicon glyphicon-chevron-down"></span> </a>
<ul class="submit_menu">
	<li><a class="english" href="<?php echo e(url('/language/en')); ?>"><?php echo e(__('English')); ?></a></li>
  	<li><a class="bangla" href="<?php echo e(url('/language/bn')); ?>"><?php echo e(__('Bangla')); ?></a></li>
</ul>
  </li>
</ul>
</div>
<div class="fulll_stak_menu">
	<div class="partision">
		
<img src="<?php echo e(asset('/public/img/onlineBD.PNG')); ?>" alt="onlineBD">
	</div>
	<div class="partision form">
		
<form action="<?php echo e(url('/search/')); ?>" method="GET">
	<input type="search" autocomplete="off"  placeholder="<?php echo e(__('Search')); ?>..." id="search" name="search"><input type="submit" name="submit" value="<?php echo e(__('Search')); ?>">
	<div class="search_result"></div>
</form>
	</div>
<div class="partision">
<div class="user_setting">
	<a href="<?php echo e(url('/wishlist')); ?>"><span class="glyphicon glyphicon-heart"></span> <span class="wo"><?php echo e(__('Wishlist')); ?></span></a>
	<a href="<?php echo e(url('/checkout')); ?>"><span class="glyphicon glyphicon-shopping-cart"></span>  <span class="wo"><?php echo e(__('Checkout')); ?></span></a>
	<a href="<?php if(Auth::check()): ?>
	<?php echo e(url('/logout')); ?>

	<?php else: ?>
	<?php echo e(url('/login')); ?>

	<?php endif; ?>"><span class="glyphicon glyphicon-user"></span> <span class="wo"><?php if(Auth::check()): ?>
	<?php echo e(__('My Account')); ?>

	<?php else: ?>
	<?php echo e(__('Login')); ?>

	<?php endif; ?></span></a>
</div>
</div>
</div><?php /**PATH C:\xampp\htdocs\project\resources\views/layout/header.blade.php ENDPATH**/ ?>