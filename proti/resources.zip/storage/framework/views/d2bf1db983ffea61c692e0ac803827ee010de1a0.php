
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
<style>
	
.login_blade .card {
	margin: 1%;
	box-shadow: 1px 1px 1px 1px #000;
}
.login_blade .card form{
	padding: 0% 10% 3% 4%;
}
body {
	background:url('<?php echo e(asset('/public/')); ?>../img/login.webp') 0 0 / 100% fixed;
}
.page-header {
    padding-bottom: 2px;
    margin: 3px 0 20px;
    border-bottom: 1px solid #eee;
}
</style>
<div class="login_blade container">
	<div class="card-group">
  <div class="card" style="background: #f8f8f8EE; order: <?php echo e($register[0]); ?>">
    	<div class="page-header">
    		<h3 class="text-center"><?php echo e(__('Login')); ?></h3>
    	</div>
		<?php if($message = Session::get('error')): ?>
	    <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
	    <?php endif; ?>
	    <?php if($errors->any()): ?>

		<?php endif; ?>


<?php if($new_account = session('new_account')): ?>
			<?php if($new_account[0]==0): ?>
	    <div class="alert alert-success" role="alert"><?php echo e($new_account[2]); ?></div>
			<?php endif; ?>
    	<?php endif; ?>



		<?php if(isset($new_account)): ?>
			<?php if($new_account[0]==1): ?>
	    <div class="alert alert-success" role="alert"><?php echo e($new_account[1]); ?></div>
			<?php endif; ?>
		<?php endif; ?>
		<form action="<?php echo e(url('login')); ?>" method="POST">
			<?php echo csrf_field(); ?>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__('Email or phone number')); ?></label>
		    <input type="text" class="form-control <?php echo e($errors->has('Email_or_Phone_number') ? ' is-invalid' : ''); ?>" name="Email_or_Phone_number" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="<?php echo e(__('Email or phone number')); ?>">
		    
		<?php if($errors->has('Email_or_Phone_number')): ?>
            <span class="help-block">
                <strong id="emailHelp" class="text-danger"><?php echo e($errors->first('Email_or_Phone_number')); ?></strong>
            </span>
        <?php endif; ?>

		  </div>
		  <?php if($redirect = Session::get('redirect')): ?>
		  <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
		  <?php else: ?>
		  <input type="hidden" name="redirect" value="">
		  <?php endif; ?>

		  <div class="form-group">
		    <label for="exampleInputPassword1"><?php echo e(__('Password')); ?></label>
		    <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="exampleInputPassword1" placeholder="<?php echo e(__('Password')); ?>">
		    <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong id="passHelp" class="text-danger"><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
		  </div>
	<div style="overflow: hidden">
		  <button type="submit" class="btn btn-primary float-right"><?php echo e(__('Login')); ?></button>
	</div>
		</form>
	</div>

	<div class="card" style="background: #f8f8f8EE; order:<?php echo e($register[1]); ?>">
		<div class="page-header">
    		<h3 class="text-center"><?php echo e(__('Register')); ?></h3>
    	</div>
    	<?php if($new_account = session('new_account')): ?>
			<?php if($new_account[0]==1): ?>
	    <div class="alert alert-danger" role="alert"><?php echo e($new_account[2]); ?></div>
			<?php endif; ?>
    	<?php endif; ?>
		<form action="<?php echo e(url('register')); ?>" method="POST">
			<?php echo csrf_field(); ?>
		  <?php if($redirect = Session::get('redirect')): ?>
		  <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
		  <?php else: ?>
		  <input type="hidden" name="redirect" value="">
		  <?php endif; ?>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__("Username")); ?></label>
		    <input type="text" class="form-control <?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>"  name="username" value="<?php echo e(old('username')); ?>" id="exampleInputEmail1" placeholder="<?php echo e(__("Username")); ?>">
		  </div>
		  <?php if($errors->has('username')): ?>
            <span class="help-block">
                <strong id="passHelp" class="text-danger"><?php echo e($errors->first('username')); ?></strong>
            </span>
        <?php endif; ?>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__('Phone number')); ?></label>
		    <input type="text" class="form-control <?php echo e($errors->has('Phone_Number') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('Phone_Number')); ?>" name="Phone_Number" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="<?php echo e(__('Phone number')); ?>">
		  </div>
		  <?php if($errors->has('Phone_Number')): ?>
            <span class="help-block">
                <strong id="passHelp" class="text-danger"><?php echo e($errors->first('Phone_Number')); ?></strong>
            </span>
        <?php endif; ?>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__('Email Address')); ?></label>
		    <input type="email" class="form-control <?php echo e($errors->has('Email') ? ' is-invalid' : ''); ?>" name="Email" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e(old('Email')); ?>" placeholder="<?php echo e(__('Email Address')); ?>">
		  </div>
		  <?php if($errors->has('Email')): ?>
            <span class="help-block">
                <strong id="passHelp" class="text-danger"><?php echo e($errors->first('Email')); ?></strong>
            </span>
        <?php endif; ?>
		  <div class="form-group">
		    <label for="exampleInputPassword1"><?php echo e(__('Password')); ?></label>
		    <input type="password" class="form-control <?php echo e($errors->has('Password') ? ' is-invalid' : ''); ?>" name="Password" id="exampleInputPassword1" placeholder="<?php echo e(__('Password')); ?>">
		  </div>
		  <?php if($errors->has('Password')): ?>
            <span class="help-block">
                <strong id="passHelp" class="text-danger"><?php echo e($errors->first('Password')); ?></strong>
            </span>
        <?php endif; ?>
<div style="overflow: hidden">
		  <button type="submit" class="btn btn-success float-right"><?php echo e(__('Create Account')); ?></button>
</div>
		</form>
	</div>
	</div>
</div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proti\resources\views/login.blade.php ENDPATH**/ ?>