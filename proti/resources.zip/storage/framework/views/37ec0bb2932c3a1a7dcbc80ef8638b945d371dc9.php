
<?php $__env->startSection('title','About page'); ?>
<?php $__env->startSection('content'); ?>

<?php if ($__env->exists("layout.header",["home"=>"about"])) echo $__env->make("layout.header",["home"=>"about"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="flex-center position-ref full-height">
<div class="content">
    <div style="text-align: center;">
       <h1>This is About Page</h1>
       <a href="<?php echo e(url('/blog')); ?>">Blog</a>
       <a href="<?php echo e(route('dk')); ?>">Make</a>
       <a href="<?php echo e(url('/contact')); ?>">Contact</a>
    </div>
<?php
	
for($i=0; $i<20; $i++)
{
echo $r = rand(10,20);
}

?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/about.blade.php ENDPATH**/ ?>