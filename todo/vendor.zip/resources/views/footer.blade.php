
<div class="ending" style="color: white; background: #0E0E0E; padding: 10px; font-style: italic; text-align: center;">
  Copyright©2021 ~ <a style="color: yellow; text-decoration: none;" href="https://www.suptokumar.com/">suptokumar.com</a> <br><br>
  Complete Your Tasks<br>
  Make Your Lucks!
</div>
