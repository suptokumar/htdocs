
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
    <div style="padding: 1%; text-align: center">
    <div class="primary_div">
        <span>Task Completed</span>
        <h2><span class="fst"><?php echo e($mov[0]); ?></span>%</h2>
    </div>
    <div class="primary_div">
        <span>Todays Tasks</span>
        <h2><span class="snd"><?php echo e($mov[1]); ?></span>%</h2>
    </div>
    </div>
    <div style="padding: 1%; text-align: center">
    <button class="btn btn-success" onclick="window.location='<?php echo e(url('add_tasks')); ?>'">Add Tasks</button>
    <button class="btn btn-info" onclick="window.location='<?php echo e(url('all_tasks')); ?>'">View All Tasks</button>
    <button class="btn btn-primary" onclick="window.location='<?php echo e(url('lifestyle')); ?>'">My Lifestyle</button>
    </div>
    <div style="padding: 1%; text-align: center">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="march march_<?php echo e($row->id); ?>">
                <div class="name_s">
                    <h4><?php echo e($row->task_name); ?></h4>
                    <h4><?php
                        echo date("h:i a",strtotime(date($row->time)));
                    ?></h4>
                    <h5>Priority: <?php echo e($row->priority); ?></h5>
                    <h5 style="color: #FF1717;">Type:
<?php
  $type = [];
?>
<?php if($row->montht==1): ?>
  <?php
    array_push($type,"Monthly");
  ?>
  <?php endif; ?>
<?php if($row->yeart==1): ?> 
  <?php
    array_push($type,"Yearly");
  ?>
  <?php endif; ?>
<?php if($row->shedule!=''): ?> 
  <?php
    array_push($type,"Weekly");
  ?>
  <?php endif; ?>
<?php if($row->shedule=='' &&  $row->yeart==0 && $row->montht==0): ?>
<?php
    array_push($type,"General");
  ?>
<?php endif; ?>

<?php for($i = 0; $i < count($type); $i++): ?>
  <?php echo e($type[$i]); ?>

  <?php if($i!=count($type)-1): ?>
    , 
  <?php endif; ?>
<?php endfor; ?>
                    </h5>
                </div>
                <div class="button_s">
                <button class="btn btn-danger" onclick="del('<?php echo e(url('/del')); ?>',0,<?php echo e($row->id); ?>,'<?php echo csrf_token() ?>',this)">Remove</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\resources\views/all_task.blade.php ENDPATH**/ ?>