
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
    <div class="port">
    	<div class="rows">
    		<div class="header">Total Collection</div>
    		<h3 class="Answer">৳ <?php echo e($total_col); ?></h3>
    	</div>
    	<div class="rows">
    		<div class="header">Todays Collection</div>
    		<h3 class="Answer">৳ <?php echo e($today_col); ?></h3>
    	</div>
        <div class="rows">
            <div class="header">Total Due</div>
            <h3 class="Answer">৳ <?php echo e($total_due); ?></h3>
        </div>
        <div class="rows">
            <div class="header">Due of <?php
                echo date("M")
            ?></div>
            <h3 class="Answer">৳ <?php echo e($mon_due); ?></h3>
        </div>
    	<div class="rows">
    		<div class="header">Total Expense</div>
    		<h3 class="Answer">৳ 0</h3>
    	</div>
    	<div class="rows">
    		<div class="header">Todays Expense</div>
    		<h3 class="Answer">৳ 0</h3>
    	</div>
    	<div class="rows">
    		<div class="header">Collection of <?php
    			echo date("M");
    		?></div>
    		<h3 class="Answer">৳ 0</h3>
    	</div>
    	<div class="rows">
    		<div class="header">Expense of <?php
    			echo date("M");
    		?></div>
    		<h3 class="Answer">৳ 0</h3>
    	</div>
    	<div class="rows">
    		<div class="header">Total Members</div>
    		<h3 class="Answer"><?php echo e($member); ?></h3>
    	</div>
    	<div class="rows">
    		<div class="header">External Fees of <?php
    			echo date("M");
    		?></div>
    		<h3 class="Answer">৳ 0</h3>
    	</div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proti\resources\views/home.blade.php ENDPATH**/ ?>