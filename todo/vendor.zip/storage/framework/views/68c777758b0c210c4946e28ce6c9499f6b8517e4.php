
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
    <div style="padding: 1%; text-align: center">
    <div class="primary_div">
        <span>Task Completed</span>
        <h2><span class="fst"><?php echo e($mov[0]); ?></span>%</h2>
    </div>
    <div class="primary_div">
        <span>Todays Tasks</span>
        <h2><span class="snd"><?php echo e($mov[1]); ?></span>%</h2>
    </div>
    </div>
    <div style="padding: 1%; text-align: center">
    <button class="btn btn-success" onclick="window.location='<?php echo e(url('add_tasks')); ?>'">Add Tasks</button>
    <button class="btn btn-info" onclick="window.location='<?php echo e(url('all_tasks')); ?>'">View All Tasks</button>
    <button class="btn btn-primary" onclick="window.location='<?php echo e(url('lifestyle')); ?>'">My Lifestyle</button>
    </div>
    <div style="padding: 1%; text-align: center">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="march march_<?php echo e($row->id); ?>">
                <div class="name_s">
                    <h4><?php echo e($row->task_name); ?></h4>
                    <h4><?php
                        echo date("h:i a",strtotime(date($row->time)));
                    ?></h4>
                    <h5>Priority: <?php echo e($row->priority); ?></h5>
                </div>
                <div class="button_s">
                <button class="btn btn-success" onclick="port('<?php echo e(url('/feedback')); ?>',1,<?php echo e($row->id); ?>,'<?php echo csrf_token() ?>',this)">Complete</button>
                <button class="btn btn-danger" onclick="port('<?php echo e(url('/feedback')); ?>',0,<?php echo e($row->id); ?>,'<?php echo csrf_token() ?>',this)">Incomplete</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\resources\views/home.blade.php ENDPATH**/ ?>