<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta charset="UTF-8">
<meta name="description" content="Free Web tutorials">
<meta name="keywords" content="HTML, CSS, JavaScript">
<meta name="author" content="John Doe">
<link rel="icon" href="<?php echo e(asset('public/img/fev.png')); ?>">
<meta property="og:title" content="ToDo: make your daily tasks let you live awesome.">
<meta property="og:description" content="you can see after a few years that what was your daily life and what is now. Go awesome do awesome.">
<meta property="og:image" content="<?php echo e(asset('/public/img/todo.PNG')); ?>">
<meta property="og:url" content="http://euro-travel-example.com/index.htm">

<meta name="twitter:title" content="ToDo: make your daily tasks let you live awesome.">
<meta name="twitter:description" content="you can see after a few years that what was your daily life and what is now. Go awesome do awesome.">
<meta name="twitter:image" content="<?php echo e(asset('/public/img/todo.PNG')); ?>">
<meta name="twitter:card" content="you can see after a few years that what was your daily life and what is now. Go awesome do awesome.">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">



    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('public/css/main.css?'.rand())); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/unedit/footer.css?'.rand())); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/js')); ?>/assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/js')); ?>/dist/bootstrap-clockpicker.min.css">
</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>

<?php if ($__env->exists("footer")) echo $__env->make("footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(asset('/public/js')); ?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('/public/js')); ?>/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('/public/js')); ?>/dist/bootstrap-clockpicker.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="<?php echo e(asset('/public/js')); ?>/main.js?<?php echo e(rand()); ?>"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\todo\resources\views/layout/app.blade.php ENDPATH**/ ?>