
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
<style>
	
.login_blade .card {
	margin: 1%;
	box-shadow: 1px 1px 1px 1px #000;
}
.login_blade .card form{
	padding: 0% 10% 3% 4%;
}
body {
	background:url('<?php echo e(asset('/public/')); ?>../img/login.webp') 0 0 / 100% fixed;
}
.page-header {
    padding-bottom: 2px;
    margin: 3px 0 20px;
    border-bottom: 1px solid #eee;
}
</style>
<div class="login_blade container">
	<div class="card-group">
  <div class="card" style="background: #f8f8f8EE; order: <?php echo e($register[0]); ?>">
    	<div class="page-header">
    		<h3 class="text-center"><?php echo e(__('Login')); ?></h3>
    	</div>
		<?php if($message = Session::get('error')): ?>
	    <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
	    <?php endif; ?>
	    <?php if($errors->any()): ?>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="alert alert-danger" role="alert"><?php echo e($error); ?></div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
		<form action="<?php echo e(url('login')); ?>" method="POST">
			<?php echo csrf_field(); ?>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__('Email or phone number')); ?></label>
		    <input type="text" class="form-control" name="Email_or_Phone_number" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="<?php echo e(__('Email or phone number')); ?>">
		    


		  </div>

		  <div class="form-group">
		    <label for="exampleInputPassword1"><?php echo e(__('Password')); ?></label>
		    <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="<?php echo e(__('Password')); ?>">
		  </div>
	<div style="overflow: hidden">
		  <button type="submit" class="btn btn-primary float-right"><?php echo e(__('Login')); ?></button>
	</div>
		</form>
	</div>

	<div class="card" style="background: #f8f8f8EE; order:<?php echo e($register[1]); ?>">
		<div class="page-header">
    		<h3 class="text-center"><?php echo e(__('Register')); ?></h3>
    	</div>
		<form action="<?php echo e(url('register')); ?>" method="POST">
			<?php echo csrf_field(); ?>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__("Username")); ?></label>
		    <input type="text" class="form-control" name="username" id="exampleInputEmail1" placeholder="<?php echo e(__("Username")); ?>">
		  </div>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__('phone number')); ?></label>
		    <input type="email" class="form-control" name="phonenumber" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="<?php echo e(__('Phone number')); ?>">
		  </div>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__('Email Address')); ?></label>
		    <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="<?php echo e(__('Email Address')); ?>">
		  </div>
		  <div class="form-group">
		    <label for="exampleInputPassword1"><?php echo e(__('Password')); ?></label>
		    <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="<?php echo e(__('Password')); ?>">
		  </div>
<div style="overflow: hidden">
		  <button type="submit" class="btn btn-success float-right"><?php echo e(__('Create Account')); ?></button>
</div>
		</form>
	</div>
	</div>
</div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8\resources\views/login.blade.php ENDPATH**/ ?>