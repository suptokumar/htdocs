
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="All_members">
<button type="button" class="btn btn-success" style="margin: 10px;" onclick="window.location='<?php echo e(url('/apply_month/')); ?>'">Apply This Monthly Fees to all</button>
<?php if($msg = session("status")): ?>
<div class="alert alert-<?php echo e($msg[0]); ?>"><?php echo e($msg[1]); ?></div>
<?php endif; ?>
	<table class="table">
		<thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Mobile</th>
      <th scope="col">Fee</th>
      <th scope="col">Options</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  		
    <tr>
      <th scope="row"><?php echo e($row->id); ?></th>
      <td><?php echo e($row->name); ?> <br> <?php if(is_null($row->month)): ?>
      	<span style="color: red">No Month</span>
      <?php endif; ?>
      	<span style="color: green"><?php echo e($row->month); ?></span></td>
      <td><?php echo e($row->phone); ?></td>
      <td><?php echo e($row->fee); ?></td>
      <td>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo e(url('/apply_month/'.$row->id)); ?>'">Apply</button>
      </td>
    </tr>
  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proti\resources\views/add_month.blade.php ENDPATH**/ ?>