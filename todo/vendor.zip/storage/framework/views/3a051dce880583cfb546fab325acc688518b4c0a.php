
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container" style="width: 80% !important;">
	<?php if($errors->any()): ?>
    <?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if($s = session('success')): ?>
<div class="alert alert-<?php echo e($s[0]); ?>"><?php echo e($s[1]); ?></div>
<?php endif; ?>
<form method="POST" action="<?php echo e(url('/add_member')); ?>" style="margin: 5% 0%; border: 1px solid #ccc; padding: 10% 16% 15% 5%">
	<?php echo csrf_field(); ?>
	<?php if(isset($edit)): ?>
	<input type="hidden" name="id" value="<?php echo e($edit->id); ?>">
	<?php endif; ?>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="inputEmail3" placeholder="member's name" name="name" <?php if(isset($edit)): ?>
	value="<?php echo e($edit->name); ?>" <?php endif; ?> required="">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Phone Number</label>
    <div class="col-sm-10">
      <input type="tel" class="form-control" id="inputEmail3" placeholder="Phone Number" name="phone" <?php if(isset($edit)): ?>
	value="<?php echo e($edit->phone); ?>" <?php endif; ?> required="">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Monthly Fee</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="inputPassword3" <?php if(isset($edit)): ?>
	value="<?php echo e($edit->fee); ?>" <?php endif; ?> placeholder="Monthly Fee" name="fee" required="">
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Add Member</button>
    </div>
  </div>
</form>
</div>


<div class="All_members">
	<table class="table">
		<thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Mobile</th>
      <th scope="col">Fee</th>
      <th scope="col">Options</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  		
    <tr>
      <th scope="row"><?php echo e($row->id); ?></th>
      <td><?php echo e($row->name); ?></td>
      <td><?php echo e($row->phone); ?></td>
      <td><?php echo e($row->fee); ?></td>
      <td>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo e(url('/add_member/'.$row->id)); ?>'">Edit</button>
<button type="button" class="btn btn-danger" onclick="window.location='<?php echo e(url('/delete_member/'.$row->id)); ?>'">Delete</button>
      </td>
    </tr>
  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proti\resources\views/add_member.blade.php ENDPATH**/ ?>