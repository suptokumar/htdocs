<style>
.top_nav a.<?php echo e($home); ?>{
	background: #1e4478;
}
</style>
<div class="fulll_stak_menu">
	<div class="partision">
		<img onclick="window.location='<?php echo e(url('/')); ?>'" src="<?php echo e(asset('/public/img/todo.PNG')); ?>" alt="" style="height:66px">
		
	</div>

<div class="partision">
<div class="user_setting">
	<a href="<?php if(Auth::check()): ?>
	<?php echo e(url('/logout')); ?>

	<?php else: ?>
	<?php echo e(url('/login')); ?>

	<?php endif; ?>"><span class="fa fa-user"></span> <span class="wo"><?php if(Auth::check()): ?>
	<?php echo e(__('Logout')); ?>

	<?php else: ?>
	<?php echo e(__('Login')); ?>

	<?php endif; ?></span></a>
</div>
</div>
</div><?php /**PATH C:\xampp\htdocs\todo\resources\views/layout/header.blade.php ENDPATH**/ ?>