
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
    <div style="padding: 1%; text-align: center">
    <div class="primary_div">
        <span>Task Completed</span>
        <h2><span class="fst"><?php echo e($mov[0]); ?></span>%</h2>
    </div>
    <div class="primary_div">
        <span>Todays Tasks</span>
        <h2><span class="snd"><?php echo e($mov[1]); ?></span>%</h2>
    </div>
    </div>
    <div style="padding: 1%; text-align: center">
    <button class="btn btn-success" onclick="window.location='<?php echo e(url('add_tasks')); ?>'">Add Tasks</button>
    <button class="btn btn-info" onclick="window.location='<?php echo e(url('all_tasks')); ?>'">View All Tasks</button>
    <button class="btn btn-primary" onclick="window.location='<?php echo e(url('lifestyle')); ?>'">My Lifestyle</button>
    </div>
    <div style="padding: 1%; text-align: center">
<form action="<?php echo e(url('lifestyle')); ?>" method="POST" style="background: white;">
	<?php echo csrf_field(); ?>
	<div class="form-group">
    <label for="date" style="text-align: left;">Date</label>
    <input type="text" class="form-control date-picker" name="date" placeholder="YYYY-MM-DD" autocomplete="off" id="date">
  </div>
  <button type="submit" class="btn btn-primary float-right">Submit</button>
</form>
    	<?php if(isset($list)): ?>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="march march_<?php echo e($row->id); ?>">
                <div class="name_s">
                    <h4><?php echo e($row->task_name); ?></h4>
                    <h4><?php
                        echo date("h:i a",strtotime(date($row->time)));
                    ?></h4>
                    <h5>Priority: <?php echo e($row->priority); ?></h5>
                </div>
                <div class="button_s">
                Status:
                <?php if($row->status==1): ?>
                <span class="badge badge-success" style="border: 1px solid green; color:green; background: white;">Completed</span>
<?php else: ?>

<span class="badge badge-danger" style="border: 1px solid red; color:red; background: white;">Not Completed</span>

                <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	<?php endif; ?>



    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\resources\views/lifestyle.blade.php ENDPATH**/ ?>