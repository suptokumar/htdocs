<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container" style="width: 80% !important;">
	<?php if($errors->any()): ?>
    <?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if($s = session('success')): ?>
<div class="alert alert-<?php echo e($s[0]); ?>"><?php echo e($s[1]); ?></div>
<?php endif; ?>
<form method="POST" action="<?php echo e(url('/collect')); ?>" style="margin: 5% 0%; border: 1px solid #ccc; padding: 10% 16% 15% 5%">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="id" value="<?php echo e($members->id); ?>">
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Due Amount</label>
    <div class="col-sm-10">
      <input type="text" readonly class="form-control" id="inputEmail3" placeholder="due amount" name="name" 
	value="<?php echo e(($members->fee)-($members->paid)); ?>" required="">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Paid Amount</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="inputPassword3"
	max="<?php echo e(($members->fee)-($members->paid)); ?>" min="0"  placeholder="paid amount" name="fee" required="">
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Collect</button>
    </div>
  </div>
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proti\resources\views/collect.blade.php ENDPATH**/ ?>