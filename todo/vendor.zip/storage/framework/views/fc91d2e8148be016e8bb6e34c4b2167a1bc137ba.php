
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
<style>
	
.login_blade .card {
	margin: 26% 6% 27% -3%;
	box-shadow: 1px 1px 1px 1px #000;
}
.login_blade .card form{
	padding: 0% 10% 3% 4%;
}
body {
	background:url('<?php echo e(asset('public/img/fev.png')); ?>') 45% 44% / 183% fixed;
}
.page-header {
    padding-bottom: 2px;
    margin: 3px 0 20px;
    border-bottom: 1px solid #eee;
}
</style>
<div class="login_blade container">
	<div class="card-group">
  <div class="card" style="background: #f8f8f8EE; order: <?php echo e($register[0]); ?>">
    	<div class="page-header">
    		<h3 class="text-center"><?php echo e(__('Register')); ?></h3>
    	</div>
		<?php if($message = Session::get('error')): ?>
	    <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
	    <?php endif; ?>
	    <?php if($errors->any()): ?>

		<?php endif; ?>


<?php if($new_account = session('new_account')): ?>
			<?php if($new_account[0]==0): ?>
	    <div class="alert alert-success" role="alert"><?php echo e($new_account[2]); ?></div>
			<?php endif; ?>
    	<?php endif; ?>


		<?php if(isset($new_account)): ?>
			<?php if($new_account[0]==1): ?>
	    <div class="alert alert-success" role="alert"><?php echo e($new_account[1]); ?></div>
			<?php endif; ?>
		<?php endif; ?>
		<form action="<?php echo e(url('register')); ?>" method="POST">
			<?php echo csrf_field(); ?>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__('Username')); ?></label>
		    <input type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('Username')); ?>">
		    
		<?php if($errors->has('name')): ?>
            <span class="help-block">
                <strong id="emailHelp" class="text-danger"><?php echo e($errors->first('name')); ?></strong>
            </span>
        <?php endif; ?>

		  </div>
		  <div class="form-group">
		    <label for="exampleInputEmail1"><?php echo e(__('Email')); ?></label>
		    <input type="text" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Email')); ?>">
		    
		<?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong id="emailHelp" class="text-danger"><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>

		  </div>
		  <?php if($redirect = Session::get('redirect')): ?>
		  <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
		  <?php else: ?>
		  <input type="hidden" name="redirect" value="">
		  <?php endif; ?>

		  <div class="form-group">
		    <label for="exampleInputPassword1"><?php echo e(__('Password')); ?></label>
		    <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="exampleInputPassword1" placeholder="<?php echo e(__('Password')); ?>">
		    <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong id="passHelp" class="text-danger"><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
		  </div>
	<div style="overflow: hidden">
		  <button type="submit" class="btn btn-primary float-right"><?php echo e(__('Create Account')); ?></button>
	</div>
	
		  <div class="form-group">
		   <a href="<?php echo e(url('/login')); ?>" class="btn btn-link">Already have an account?</a>
		  </div>
		</form>
	</div>

	</div>
</div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\resources\views/register.blade.php ENDPATH**/ ?>