
<div class="ending" style="color: white; background: #0E0E0E; padding: 10px; font-style: italic; text-align: center;">
  Copyright©2021 ~ <a style="color: yellow; text-decoration: none;" href="https://www.suptokumar.com/">থিয়েটার প্রতিচ্ছবি</a>. <br><br>
  Contact: +88 01884-082922<br><br>
  Ullapara Merchant's Pilot Govt High School<br>
  Ullapara, Sirajganj<br><br><br>
আপন প্রতিভার প্রতিচ্ছবিতে বিবেকবান মানুষ হই।
</div>
<?php /**PATH C:\xampp\htdocs\proti\resources\views/footer.blade.php ENDPATH**/ ?>