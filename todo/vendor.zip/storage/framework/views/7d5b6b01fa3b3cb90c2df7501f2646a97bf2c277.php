
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php if ($__env->exists("layout.header",["home"=>"home"])) echo $__env->make("layout.header",["home"=>"home"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="flex-center position-ref full-height">
<div class="content">
    <div style="text-align: center;">
       <h1>This is Home Page</h1>
       <a href="<?php echo e(url('/blog')); ?>">Blog</a>
       <a href="<?php echo e(route('dk')); ?>">Make</a>
       <a href="<?php echo e(url('/contact')); ?>">Contact</a>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proti\resources\views/home.blade.php ENDPATH**/ ?>