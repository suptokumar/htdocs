@extends("layout.app")
@section("title","School management software")
@section("active","products")
@section("content")
 <article>This is a theme that I will use</article>
    <article>This is a theme that I will use</article>
    <article>This is a theme that I will use</article>
    <article>This is a theme that I will use</article>
@endsection