
<?php $__env->startSection("title","School management software"); ?>
<?php $__env->startSection("active","products"); ?>
<?php $__env->startSection("content"); ?>
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
background: none;
}
</style>
 <article>

<div class="row">
	<div class="col-4">
		<div style="padding: 2%; background: white; margin: 10px; border-radius: 10px; border: 1px solid #ccc; text-align: center;">
		<img src="<?php echo e(url(empty(Auth::user()->image)?"/public/logo/ag.jpg":"/public/image/0".Auth::user()->image)); ?>" alt="<?php echo e(Auth::user()->name); ?>" style="width: 200px; border-radius: 100%;">
		<h2><?php echo e(Auth::user()->name); ?></h2>
		<?php if(Auth::user()->type==2): ?>
			
		<h5>Client ID:<?php echo e(Auth::user()->gurdain_id); ?></h5>
		<?php endif; ?>
		<div style="text-align: left">
<h6>Email: <?php echo e(Auth::user()->email); ?></h6>
<h6>Phone Number: <?php echo e(Auth::user()->phone); ?></h6>

<?php if(Auth::user()->type!=2): ?>
<h6>ID Number: <?php echo e(Auth::user()->national_id); ?></h6>

<br>
<br>

<h6>Zoom Link:<br><a style="line-break: anywhere;" href="<?php echo e(Auth::user()->zoom_link); ?>" target="_blank"><?php echo e(Auth::user()->zoom_link); ?></a></h6>
<h6>Calender Link:<br><a style="line-break: anywhere;" href="<?php echo e(Auth::user()->calender_link); ?>" target="_blank"><?php echo e(Auth::user()->calender_link); ?></a></h6>

<?php endif; ?>
		</div>
		</div>

<?php if(Auth::user()->type==2): ?>
<div style="padding: 2%; background: white; margin: 10px; border-radius: 10px; border: 1px solid #ccc; text-align: center;">
<h3>Student Evalution</h3>
<p>
	<?php echo e(Auth::user()->evalu); ?>

</p>
</div>
<div style="padding: 2%; background: white; margin: 10px; border-radius: 10px; border: 1px solid #ccc; text-align: center;">
<h3>Regular Evalution</h3>
<p>
	<?php echo e(Auth::user()->reg_evalu); ?>

</p>
		</div>

<?php else: ?>
<div style="padding: 2%; background: white; margin: 10px; border-radius: 10px; border: 1px solid #ccc; text-align: center;">
<h3>My Bio</h3>
<p>
	<?php echo e(Auth::user()->bio); ?>

</p>
		</div>


<div class="row" style="padding: 2%; margin: 10px; border-radius: 10px; border: 1px solid #ccc; text-align: center;">
	<div class="round col-3">
	<a href="<?php echo e(url('/public/image/0')); ?><?php echo e(Auth::user()->cv); ?>" target="_blank">Visit CV</a>
	</div>
	<div class="round col-3">
	<a target="_blank" href="<?php echo e(url('/public/image/0')); ?><?php echo e(Auth::user()->national_id_front); ?>"><img style='width: 100%' src="<?php echo e(url('/public/image/0')); ?><?php echo e(Auth::user()->national_id_front); ?>" alt="National ID front Copy"></a>
	</div>
	<div class="round col-3">
	<a target="_blank" href="<?php echo e(url('/public/image/0')); ?><?php echo e(Auth::user()->national_id_back); ?>"><img style='width: 100%' src="<?php echo e(url('/public/image/0')); ?><?php echo e(Auth::user()->national_id_back); ?>" alt="National ID back Copy"></a>

	</div>
</div>

<?php endif; ?>
	</div>
<style>
	.round {
    background: white;
    text-align: center;
    border-radius: 17px;
    padding: 13px;
    margin: 10px;
}
</style>
	<div class="col-8">
		<div class="row">
<div class="col-4">
<div class="round">
<h5>Previous Class Report</h5>
<?php if(Auth::user()->type==2): ?>
<a href="<?php echo e(url('/student/manage_class')); ?>" target="_blank">Click Here</a>
<?php elseif(Auth::user()->type==1): ?>
<a href="<?php echo e(url('/teacher/manage_class')); ?>" target="_blank">Click Here</a>

<?php endif; ?>
</div>
</div>
<div class="col-4">
<div class="round">
<h5>Upcoming Classes in Month</h5>
<a href="<?php echo e(url('/upcoming/'.Auth::id())); ?>" target="_blank">Click Here</a>
</div>
</div>
<div class="col-4">
<div class="round">
<h5><?php echo e(Auth::user()->type==1?"Done Hours":"Remaining Hours"); ?></h5>
<?php if(intval(Auth::user()->hours)==0): ?>
			<h3 style="color:<?php echo e(Auth::user()->hours<61?'red;':'blue'); ?>">0:00</h3>
			<?php else: ?>
      <h3 class="bioer"  style="color:<?php echo e(Auth::user()->hours<61?'red;':'blue'); ?>"><?php echo e(floatval(Auth::user()->hours)>0?(floor(floatval(Auth::user()->hours) / 60) .':'. floatval(Auth::user()->hours) % 60):("-".floor(floatval(-1*Auth::user()->hours) / 60) .':'. floatval(-1*Auth::user()->hours) % 60)); ?></h3>
<?php endif; ?>
</div>
</div>
		</div>
			<div style="padding: 2%; background: white; margin: 10px; border-radius: 10px; border: 1px solid #ccc; ">
<div class="row">
<div class="col-sm-6 m-2" style="border-right: 1px solid #ccc;">
<h6>Country: <?php echo e(Auth::user()->country); ?></h6>
<h6>Timezone: <?php echo e(Auth::user()->timezone); ?></h6>
<h6>Gender: <?php echo e(Auth::user()->gender); ?></h6>
<h6>Birthday: <?php echo e(Auth::user()->dateofbirth); ?></h6>
<h6>Address: <?php echo e(Auth::user()->address1); ?></h6>
</div>
<?php
	use App\Models\report;
	use App\Models\User;
	if(Auth::user()->type==2)
	{
	$r = report::where("s_id","=",Auth::id())->get();
}else{
	$r = report::where("t_id","=",Auth::id())->get();
}
$subject = [];
$clt = [];
foreach ($r as $key => $value) {
		if(!in_array($value->subject,$subject )){

	array_push($subject,$value->subject);
}

	if(Auth::user()->type==2)
{
	if(!in_array(User::find($value->t_id)->name,$clt )){

	array_push($clt,User::find($value->t_id)->name);
	}
}else{
if(!in_array(User::find($value->s_id)->name,$clt )){
		
	array_push($clt,User::find($value->s_id)->name);
	}}
}
?>
<div class="col-sm-4 m-2">
<h6>Subjects: <?php echo e(implode(",",$subject)); ?></h6>
<h6><?php if(Auth::user()->type==2): ?>
	Teacher:
<?php else: ?>
Students:
<?php endif; ?>

<?php echo e(implode(",",$clt)); ?></h6>
<h6>Cancel Request: <?php echo e(Auth::user()->cancel_request); ?></h6>
<?php if(Auth::user()->type!=2): ?>
<h6>Graduation: <?php echo e(Auth::user()->graduation); ?></h6>
<h6>Education: <?php echo e(Auth::user()->education); ?></h6>
<?php endif; ?>
</div>
</div>


		</div>
		<div style="padding: 2%; background: white; margin: 10px; border-radius: 10px; border: 1px solid #ccc; text-align: center;">

<div class="pre_class">
	<h3>Current Month Reports
</h3>
  
<table class="table" id="tablon"> 
    <thead class="thead-light"> 
      <tr> 
        <th scope="col">#</th>
        <th scope="col">Class Title</th>
        <th scope="col">Subject</th>
        <th scope="col"><?php echo e(Auth::user()->type==2?"Teacher":"Student"); ?></th>
        <th scope="col">Duration</th>
        <th scope="col">Time</th>
        <th scope="col">Progress Notes</th>
      </tr>
    </thead>
  <tbody>
      <?php if(empty($report)): ?>
    <td colspan="7">Nothing Found</td>
  <?php endif; ?>
  <?php
    $i = 0;
  ?>
 <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php
   date_default_timezone_set($r->timezone);
   $m = strtotime($r->lastclass);
   date_default_timezone_set(Auth::user()->timezone);
 ?>
      <tr> 
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($r->title); ?></td>
        <td><?php echo e($r->subject); ?></td>
        <td><?php echo e($r->client); ?></td>
        <td><?php echo e($r->duration); ?> Minutes</td>
        <td><?php echo e(date("d M Y h:ia",$m)); ?></td>
        <td><?php echo e($r->notes); ?></td>
      </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  </tbody>
  </table>
</div>

	</div>
</div>


 </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\platform\resources\views/profile.blade.php ENDPATH**/ ?>