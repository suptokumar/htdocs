
<?php $__env->startSection("title","Create Client | School management software"); ?>
<?php $__env->startSection("active","settings"); ?>
<?php $__env->startSection("content"); ?>
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
}
</style>
 <article>

<form style="width: 90%; margin: 0 auto;" action="<?php echo e(url('/reqs_t')); ?>" method="POST" enctype="multipart/form-data"><br>
	<h3 style="text-align: center;">Request To Change Schedule</h3>
			<?php if($message = session("message")): ?>
	<div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
	<div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>

<?php if($new_client = session("new_client")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($new_client); ?>

</div>
<?php endif; ?>
<style>
  .dup{
    float: left;
  }
</style>
 <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__("Select Time")); ?></label>
    <div style="overflow: hidden;">
      
    <div class="dup clockpicker" style="width: 40%"><input type="text" class="form-control" id="time" name="time" aria-describedby="emailHelp"  value="<?php echo e(date("H:i",strtotime($course->starting))); ?>" placeholder="H:M"></div>
    <div class="dup" style="width: 40%"><input type="date" class="form-control" id="date" name="date" aria-describedby="emailHelp"  value="<?php echo e(date("Y-m-d")); ?>"></div>
    </div>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Set Timezone')); ?></label>
    <div style="position: relative;">
    	
    <input type="text" class="form-control" id="timezone" name="timezone" aria-describedby="emailHelp"  value="<?php echo e($course->timezone); ?>" placeholder="Start Typing">
    </div>
  </div>
<?php echo csrf_field(); ?>
    <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Repeat Class')); ?></label>
    <input type="hidden" class="form-control" id="repeat" name="repeat" aria-describedby="emailHelp"  value="<?php echo e($course->repeat); ?>" placeholder="What class are you in?">
    <div class="col-sm-10">
    	<?php
    		function mg_co($val,$arrs){
    			$arr = explode(",",$arrs);
    			if(in_array($val, $arr)){
    				echo "selected";
    			}
    		}
    	?>
      <div class="days">
        <input type="button" class="day_tog day_ml <?php echo e(mg_co("Sunday",$course->repeat)); ?>" id="Sunday"  value="Sunday">
        <input type="button" class="day_tog day_ml <?php echo e(mg_co("Monday",$course->repeat)); ?>" id="Monday"  value="Monday">
        <input type="button" class="day_tog day_ml <?php echo e(mg_co("Tuesday",$course->repeat)); ?>" id="Tuesday" value="Tuesday">
        <input type="button" class="day_tog day_ml <?php echo e(mg_co("Wednesday",$course->repeat)); ?>" id="Wednesday"  value="Wednesday">
        <input type="button" class="day_tog day_ml <?php echo e(mg_co("Thursday",$course->repeat)); ?>" id="Thursday" value="Thursday">
        <input type="button" class="day_tog day_ml <?php echo e(mg_co("Friday",$course->repeat)); ?>" id="Friday"  value="Friday">
        <input type="button" class="day_tog day_ml <?php echo e(mg_co("Saturday",$course->repeat)); ?>" id="Saturday" value="Saturday">
        <br>
      </div>
    </div>
  </div>

 <input type="hidden" name="del" value="<?php echo e($id); ?>">
  <div style="padding: 10px; overflow: hidden">
  <button type="submit" class="btn btn-success" style="float: right;">Save</button>
  </div>
</form>


 </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/boot/dist')); ?>/bootstrap-tagsinput.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/js')); ?>/bootstrap-clockpicker.min.css">
<script type="text/javascript" src="<?php echo e(asset('/public/js')); ?>/bootstrap-clockpicker.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('/public/boot/dist')); ?>/bootstrap-tagsinput.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('/public/boot/dist')); ?>/bootstrap-tagsinput-anglular.min.js"></script>
  <script src="<?php echo e(asset('/public/js/admin.js?'.rand())); ?>"></script>

<script>
	$('.clockpicker').clockpicker({
placement: 'bottom',
align: 'left',
donetext: 'Done'
});
		autocomplete(document.querySelector("#timezone"),<?php
		echo json_encode(timezone_identifiers_list());
	?>);

</script>
<style>
  .selected{
    background: green;
    color: white;
  }
  .bost{
    background: #C7C7C7 !important;
    color: black !important;
    border: 1px solid black !important;
  }
    .day_tog {
    padding: 4px 10px;
    border: 1px solid #ccc;
    border-radius: 10px;
    cursor: pointer;
    margin: 5px;
  }
  .label-info {
  background: #2b7be2;
  padding: 2px 4px 4px 6px;
  border-radius: 10px;
}
.label-info span {
  color: #ffbfb4;
  font-weight: bold;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/request_change.blade.php ENDPATH**/ ?>