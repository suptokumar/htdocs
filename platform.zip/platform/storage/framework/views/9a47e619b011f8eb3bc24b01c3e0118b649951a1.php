
<?php $__env->startSection("title","Create Client | School management software"); ?>
<?php $__env->startSection("active","settings"); ?>
<?php $__env->startSection("content"); ?>
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
}
</style>
 <article>

<form style="width: 90%; margin: 0 auto;" action="<?php echo e(url('/upload_note')); ?>" method="POST" enctype="multipart/form-data"><br>
	<h3 style="text-align: center;">Create Progress Notes</h3>
			<?php if($message = session("message")): ?>
	<div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
	<div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>

<?php if($new_client = session("new_client")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($new_client); ?>

</div>
<?php endif; ?>
<?php if($d==1): ?>
Sorry The Time is up. You can't upload the Progress Note now.
<?php endif; ?>

<?php if($d==0): ?>
 <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Update Progress Notes')); ?></label>
    <textarea class="form-control" id="assignment" name="assignment" style="height: 250px;">
* Previous assignment:
* Lesson topic       :
* Class performance  :
* New assignment     :
</textarea>
  </div>
<input type="hidden" name="id"  value="<?php echo e(Auth::user()->id); ?>">
<input type="hidden" name="as"  value="<?php echo e($report); ?>">
<input type="hidden" name="type"  value="1">
<?php echo csrf_field(); ?>
 
  <div style="padding: 10px; overflow: hidden">
  <button type="submit" class="btn btn-success" style="float: right;">Save</button>
  </div>
<?php endif; ?>
</form>


 </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/knowlfi9/public_html/platform/resources/views/note_upload.blade.php ENDPATH**/ ?>