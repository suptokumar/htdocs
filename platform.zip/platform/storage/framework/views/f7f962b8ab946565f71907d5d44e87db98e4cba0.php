
<?php $__env->startSection("title","My Class | School management software"); ?>
<?php $__env->startSection("active","my_class"); ?>
<?php $__env->startSection("content"); ?>
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
}
.rab{
	padding: 10px 20px;
	border: 1px solid #ccc;
	border-radius: 8px;
	width: auto;
	margin: 10px;
	float: left;
}
</style>
 <article>



<div class="search" style="width: 100%; padding: 2%; overflow: hidden">
	<div class="rk" style="float: right; align-items: center;">
		Search <input type="search" id="snod410" autocomplete="off" onkeyup="show_class(1)" style="padding: 10px; border: 1px solid #ccc; outline: none;" placeholder="Search">
	</div>
	<div class="parts">
		<div class="rab">
			<h5><?php echo e(Auth::user()->type==1?"Done Hours":"Remaining Hours"); ?></h5>
			<?php if(Auth::user()->hours==0): ?>
			<h3 style="color:<?php echo e(Auth::user()->hours<61?'red;':'blue'); ?>">0:00</h3>
			<?php else: ?>
			<h3 style="color:<?php echo e(Auth::user()->hours<61?'red;':'blue'); ?>"><?php echo e(intval(Auth::user()->hours)>0?(floor(intval(Auth::user()->hours) / 60) .':'. intval(Auth::user()->hours) % 60):("-".floor(intval(-1*Auth::user()->hours) / 60) .':'. intval(-1*Auth::user()->hours) % 60)); ?></h3>
		    <?php endif; ?>
		</div>
	</div>

	<div class="parts">
		<div class="rab">
			<h6>Attended Classes</h6>
			<h5>Total: <?php echo e($attend[0]); ?></h5>
			<h5>Month: <?php echo e($attend[1]); ?></h5>
		</div>
		<div class="rab">
			<h6>Not Attended Classes</h6>
			<h5>Total: <?php echo e($not_attended[0]); ?></h5>
			<h5>Month: <?php echo e($not_attended[1]); ?></h5>
		</div>
		<?php if(isset($last_payment)): ?>
		<div class="rab">
			<h6>Payments</h6>
			<h6>Last Payment: <?php echo e($last_payment[0]); ?></h6>
			<h6>Upcoming: <?php echo e($last_payment[1]); ?></h6>
		</div>
		<?php endif; ?>
	</div>
	<div class="dk">
<input type="hidden" value="<?php echo e(csrf_token()); ?>" id="csrf">
	</div>
</div>
<div class="all_class" style="width: 100%">
	
</div>

<input type="hidden" id="today" value="<?php echo e(time()); ?>">


 </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>

  <script src="<?php echo e(asset('/public/js/class.js?ceedf')); ?>"></script>
<script>
	$(document).ready(function() {
		show_class(1);
	});
	function dp_fun(page){
		show_class(page);

	}
</script>
<style>
	
.moce10 {
  padding: 10px;
  margin: 10px;
  border: 1px solid #ccc;
}
.moce10.new_one {
  background: #e6f8ff;
}
.moce10 .btn {
  float: right;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\platform\resources\views/my_class.blade.php ENDPATH**/ ?>