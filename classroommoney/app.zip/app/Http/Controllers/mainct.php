<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Hash;
use App\Models\User;
use App\Models\course;
use App\Models\notification;
use App\Models\client;
use App\Mail\email;
use Illuminate\Support\Facades\Mail;
use DB;
use File;
use Image;
class mainct extends Controller
{
    public function index(){
    		return view("index");
    }
    public function login(){
    	if (Auth::check()) {
            return redirect('/');
        
    }
		return view("login",["active"=>"login"]);
    }
    
    
    public function logined(Request $request){
    	if (Auth::check()) {
            return redirect('/');
        }else{
            $this->validate($request,[
                'login'=>'required',
                'pass'=>'required|alphaNum|min:4'
            ]);

            

            $user_details2s = [
                'email'=>$request->get("login"),
                'password'=>$request->get("pass")
            ];
            if (Auth::attempt($user_details2s, true)) {
                    if(Auth::user()->key==1){
                        Auth::logout();
                        return back()->with('error','You are blocked.');
                    }
                if ($request->get("redirect")=='') {
                    return redirect('/');
                }
                return new RedirectResponse($request->get("redirect"));
            }else{
                $user_details2 = [
                'phone'=>$request->get("login"),
                'password'=>$request->get("pass")
            ];
                if (Auth::attempt($user_details2, true)) {
                    if(Auth::user()->key==1){
                        Auth::logout();
                        return back()->with('error','You are blocked.');
                    }
                if ($request->get("redirect")=='') {

                    return redirect('/');
                }
                return new RedirectResponse($request->get("redirect"));
        }
            }
            return back()->with('error','Wrong Login Details.');
            
    }
    }
    public function create_client(){
        return view("create_client");
    }
    public function create_clients(Request $request){
        $client = new client;
        $client->name = $this->null_pointer($request->get("name"));
        $client->payment = $this->null_pointer($request->get("payment"));
        $client->email = $this->null_pointer($request->get("email"));
        $client->phone = $this->null_pointer($request->get("phone"));
        $client->hours = 0;
        $client->last_paid = '1111-11-11';
        $client->child = 1;
        $key = time().rand(1,100);
        $client->key = $key;
        if ($client->save()) {
            $me = User::find(Auth::id());
            $me->gurdain_id = $key;
            $me->save();
            return redirect("student/settings")->with("new_client",__("You created a new client info. Your client id added to your account."));
        }
    }
    public function details($id){
        if (User::find($id)) {
return view("user_details",["user"=> User::find($id)]);
        }else{
            return back();
        }
    }
    public function logout(){
    	if (Auth::check()) {
            Auth::logout();
            return redirect('/');
        }else{
        return back();
        }
    }
    
    public function register(){
		return view("register",["active"=>"register"]);
    	
    }
    
    public function registered(Request $request){
    	$name = $request->get("name");
    	$email = $request->get("email");
    	$phone = $request->get("phone");
    	$password = $request->get("password");
    	$type = $request->get("type");
        $timezone = $request->get("timezone");
        $country = $request->get("country");
    	$this->validate($request,[
            'name'=>'required',
            'phone'=>'required',
            'email'=>'required|email',
            'password'=>'required|alphaNum|min:4',
            'timezone'=>'required|min:4',
        ]);
$pre_user = User::where("email","=",$email)->count();
if ($pre_user!=0) {
	return back()->with("message",__('The email is already in.'));
}

$pre_users = User::where("phone","=",$phone)->count();
if ($pre_users!=0) {
	return back()->with("message",__('The phone number is already in.'));
}


    	$user = new User;

    	$user->name = $name;
    	$user->image =  '';
    	$user->phone =  $phone;
    	$user->password= Hash::make($password);
    	$user->type = $type;
    	$user->email = $email;
    	$user->key = 0;
$user->address1 = '';
$user->country = $country;
$user->timezone = $timezone;
$user->gurdain_id = '';
$user->hours = '';
$user->education = '';
$user->national_id = '';
$user->national_id_front = '';
$user->national_id_back = '';
$user->cv = '';
$user->bio = '';
$user->calender_link = '';
$user->image = '';
$user->zoom_link = '';
$user->gender = '';
$user->dateofbirth='2020-04-22';
    	if ($user->save()) {
            if ($request->refil==1) {
            return back()->with("success",$name.__("'s Account Created Successfuly."));
            }else{

    		return redirect("/login")->with("message",__("Your Account Created Successfuly."));
            }
    	}else{
    		return back()->with("message",__("Failed to create $name 's account."));
    	}
    }
    public function update(Request $request){
        $id = $request->get("id");
        $name = $this->null_pointer($request->get("name"));
        $address1 = $this->null_pointer($request->get("address1"));
        $country = $request->get("country");
        $timezone = $request->get("timezone");
        $user = User::find($id);

        $user->name = $name;
$user->address1 = $address1;
$user->country = $country;
$user->timezone = $timezone;
if (Auth::user()->type==2) {
        $dateofbirth = $request->get("dateofbirth");
$gurdain_id = $this->null_pointer($request->get("gurdain_id"));
$search_gur = client::where("key","=",$gurdain_id)->count();
if ($search_gur!=0) {
$user->gurdain_id = $gurdain_id;
}else{
    return back()->with("message",__("Your Client not found."));
}
$user->dateofbirth=$dateofbirth;

$national_id_back = '';
$user->national_id = '';
$user->national_id_front = '';
$user->national_id_back = '';
$user->cv = '';
$user->bio = '';
$user->calender_link = '';
$user->zoom_link ='';
$user->gender = '';
$user->education = '';



}else{
$education = $this->null_pointer($request->get("education"));
$national_id = $this->null_pointer($request->get("national_id"));
$bio = $this->null_pointer($request->get("bio"));
$calender_link = $this->null_pointer($request->get("calender_link"));
$zoom_link = $this->null_pointer($request->get("zoom_link"));
$gender = $this->null_pointer($request->get("gender"));
$national_id_front = '';
$national_id_back = '';
$cv = '';


if ($request->hasFile('national_id_front')) {
        $r =  imagecreatefromstring(file_get_contents($request->file('national_id_front')->getPathName()));
// Save the image

$path = public_path()."/image/";
$national_id_front = time().rand().".webp";
imagewebp($r, $path."0".$national_id_front);
}else{
    $national_id_front = $user->national_id_front;

}


if ($request->hasFile('national_id_back')) {
        $r =  imagecreatefromstring(file_get_contents($request->file('national_id_back')->getPathName()));
// Save the image

$path = public_path()."/image/";
$national_id_back = time().rand().".webp";
imagewebp($r, $path."0".$national_id_back);
}else{
    $national_id_back = $user->national_id_back;
}


if ($request->hasFile('cv')) {
        $r =  $request->file('cv')->getPathName();
// Save the image

$path = public_path()."/image/";
$cv = time().rand().$request->file('cv')->getClientOriginalName();
move_uploaded_file($r, $path."0".$cv);
}else{
    $cv = $user->cv;
}






$user->national_id = $national_id;
$user->national_id_front = $national_id_front;
$user->national_id_back = $national_id_back;
$user->cv = $cv;
$user->bio = $bio;
$user->calender_link = $calender_link;
$user->gurdain_id = '';
$user->zoom_link = $zoom_link;
$user->gender = $gender;
$user->education = $education;


}
$user->hours = Auth::user()->hours;
$image = '';
if ($request->hasFile('image')) {
        $r =  imagecreatefromstring(file_get_contents($request->file('image')->getPathName()));
// Save the image
$path = public_path()."/image/";
$image = time().rand().".webp";
imagewebp($r, $path."0".$image);
}




$user->image = $image;
        if ($user->save()) {
            return back()->with("success",__("Your account updated successfuly."));
        }else{
            return back()->with("message",__("Failed to update your account."));
        }
    }

    public function users(){
        return view("admin.users");
    }
    public function null_pointer($val){
if (empty($val)) {
    return "";
}else{
    return $val;
    }
}









// functions for the admin

    function user_list(Request $request){
        $search = $request->get("search");
        $order = $request->get("order");
        $and = '';
        if ($order == 0) {
            $and = "users WHERE (name LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%') AND type!=3";
        }
        if ($order==1) {
            $and = "users WHERE (name LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%') AND type=2";
        }
        if ($order==2) {
            $and = "users WHERE (name LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%') AND type=1";
        }
        // $page = 1;
        $page = $request->get("page");
        $limit = 15;
        $from = ($page-1)*$limit;
        $result = DB::select("SELECT * FROM ".$and." ORDER BY CASE
WHEN name='$search' THEN 0
WHEN email='$search' THEN 0
WHEN phone='$search' THEN 0
WHEN name LIKE '$search%' THEN 1
WHEN email LIKE '$search%' THEN 1
WHEN phone LIKE '$search%' THEN 1
WHEN name LIKE '_$search%' THEN 2
WHEN email LIKE '_$search%' THEN 2
WHEN phone LIKE '_$search%' THEN 2
WHEN name LIKE '__$search%' THEN 3
WHEN email LIKE '__$search%' THEN 3
WHEN phone LIKE '__$search%' THEN 3
WHEN name LIKE '___$search%' THEN 4
WHEN email LIKE '___$search%' THEN 4
WHEN phone LIKE '___$search%' THEN 4
WHEN name LIKE '____$search%' THEN 5
WHEN email LIKE '____$search%' THEN 5
WHEN phone LIKE '____$search%' THEN 5
WHEN name LIKE '_____$search%' THEN 6
WHEN email LIKE '_____$search%' THEN 6
WHEN phone LIKE '_____$search%' THEN 6
WHEN name LIKE '______$search%' THEN 7
WHEN email LIKE '______$search%' THEN 7
WHEN phone LIKE '______$search%' THEN 7
WHEN name LIKE '_______$search%' THEN 8
WHEN email LIKE '_______$search%' THEN 8
WHEN phone LIKE '_______$search%' THEN 8
WHEN name LIKE '________$search%' THEN 9
WHEN email LIKE '________$search%' THEN 9
WHEN phone LIKE '________$search%' THEN 9
WHEN name LIKE '_________$search%' THEN 10
WHEN email LIKE '_________$search%' THEN 10
WHEN phone LIKE '_________$search%' THEN 10
WHEN name LIKE '__________$search%' THEN 11
WHEN email LIKE '__________$search%' THEN 11
WHEN phone LIKE '__________$search%' THEN 11
WHEN name LIKE '___________$search%' THEN 12
WHEN email LIKE '___________$search%' THEN 12
WHEN phone LIKE '___________$search%' THEN 12 END, name ASC LIMIT $from,$limit;
            ");
        $total = DB::select("SELECT id FROM ".$and." ORDER BY CASE
WHEN name='$search' THEN 0
WHEN email='$search' THEN 0
WHEN phone='$search' THEN 0
WHEN name LIKE '$search%' THEN 1
WHEN email LIKE '$search%' THEN 1
WHEN phone LIKE '$search%' THEN 1
WHEN name LIKE '_$search%' THEN 2
WHEN email LIKE '_$search%' THEN 2
WHEN phone LIKE '_$search%' THEN 2
WHEN name LIKE '__$search%' THEN 3
WHEN email LIKE '__$search%' THEN 3
WHEN phone LIKE '__$search%' THEN 3
WHEN name LIKE '___$search%' THEN 4
WHEN email LIKE '___$search%' THEN 4
WHEN phone LIKE '___$search%' THEN 4
WHEN name LIKE '____$search%' THEN 5
WHEN email LIKE '____$search%' THEN 5
WHEN phone LIKE '____$search%' THEN 5
WHEN name LIKE '_____$search%' THEN 6
WHEN email LIKE '_____$search%' THEN 6
WHEN phone LIKE '_____$search%' THEN 6
WHEN name LIKE '______$search%' THEN 7
WHEN email LIKE '______$search%' THEN 7
WHEN phone LIKE '______$search%' THEN 7
WHEN name LIKE '_______$search%' THEN 8
WHEN email LIKE '_______$search%' THEN 8
WHEN phone LIKE '_______$search%' THEN 8
WHEN name LIKE '________$search%' THEN 9
WHEN email LIKE '________$search%' THEN 9
WHEN phone LIKE '________$search%' THEN 9
WHEN name LIKE '_________$search%' THEN 10
WHEN email LIKE '_________$search%' THEN 10
WHEN phone LIKE '_________$search%' THEN 10
WHEN name LIKE '__________$search%' THEN 11
WHEN email LIKE '__________$search%' THEN 11
WHEN phone LIKE '__________$search%' THEN 11
WHEN name LIKE '___________$search%' THEN 12
WHEN email LIKE '___________$search%' THEN 12
WHEN phone LIKE '___________$search%' THEN 12 END, name ASC;
            ");
    return json_encode([$result,[count($total), $page, $limit]]);
    }






// functions for the admin to manage class

    function get_classes(Request $request){
        $search = $request->get("search");
        $and = "courses WHERE (title LIKE '%$search%' OR subject LIKE '%$search%' OR teacher LIKE '%$search%' OR student LIKE '%$search%')";
        

        // $page = 1;
        $page = $request->get("page");
        $limit = 15;
        $from = ($page-1)*$limit;
        $result = DB::select("SELECT * FROM ".$and." ORDER BY title ASC LIMIT $from,$limit;
            ");
        $total = DB::select("SELECT id FROM ".$and." ORDER BY title ASC;
            ");
        $starting_time = [];
        $status = [];
        foreach ($result as $key => $value) {
            $result[$key]->repeat = substr($value->repeat, 1);
            date_default_timezone_set($value->timezone);
            $pre_v = strtotime($value->starting);
            $result[$key]->guest = substr($value->guest, 1);
            date_default_timezone_set(Auth::user()->timezone);
            array_push($starting_time, [date("Y-m-d h:ia", $pre_v), date_default_timezone_get()]);
            if ($value->repeat=='' && strtotime($value->starting)>time()) {
            array_push($status, "Finished");
            }else{
            array_push($status, "Open");
            }
        }
    return json_encode([$result,[count($total), $page, $limit],$starting_time,$status]);
    }





// functions for the admin

  public  function notifications(Request $request){
        $search = $request->get("search");
        if (Auth::user()->type==3) {
            $role = "Admin";
        }else{

            $role = Auth::user()->id;
        }
        $and = "notifications WHERE user='".$role."' AND content LIKE '%$search%'";
        

        // $page = 1;
        $page = $request->get("page");
        $limit = 1;
        $from = ($page-1)*$limit;
        $result = DB::select("SELECT * FROM ".$and." ORDER BY id DESC LIMIT $from,$limit;
            ");
        $total = DB::select("SELECT id FROM ".$and." ORDER BY id DESC;
            ");

        foreach ($result as $key => $value) {
            $noti = notification::find($value->id);
            $noti->read=1;
            $noti->save();
        }
    return json_encode([$result,[count($total), $page, $limit]]);
    }

public function delete_noti(Request $request){
$noti = notification::find($request->get("id"));
$noti->delete();
return 0;
}

public function manage_class(){
return view("admin.manage_class");
}

public function block(Request $request){
    $id =  $request->get("id");

    $user = User::find($id);

    if ($user->key==0) {
        $user->key=1;
        $user->save();
        return "Unblock";
    }else{
        $user->key=0;
        $user->save();
        return "Block";
    }
}




public function settings(){
    return view("settings");
}




public function add_class(){
    return view("admin.add_class");
}









    function user_get(Request $request){
        $search = $request->get("s");
        $type = $request->get("type");
            $and = "users WHERE (name LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%') AND type='$type'";
        
        $page = 1;
        $limit = 25;
        $from = ($page-1)*$limit;
        $result = DB::select("SELECT * FROM ".$and." ORDER BY CASE
WHEN name='$search' THEN 0
WHEN email='$search' THEN 0
WHEN phone='$search' THEN 0
WHEN name LIKE '$search%' THEN 1
WHEN email LIKE '$search%' THEN 1
WHEN phone LIKE '$search%' THEN 1
WHEN name LIKE '_$search%' THEN 2
WHEN email LIKE '_$search%' THEN 2
WHEN phone LIKE '_$search%' THEN 2
WHEN name LIKE '__$search%' THEN 3
WHEN email LIKE '__$search%' THEN 3
WHEN phone LIKE '__$search%' THEN 3
WHEN name LIKE '___$search%' THEN 4
WHEN email LIKE '___$search%' THEN 4
WHEN phone LIKE '___$search%' THEN 4
WHEN name LIKE '____$search%' THEN 5
WHEN email LIKE '____$search%' THEN 5
WHEN phone LIKE '____$search%' THEN 5
WHEN name LIKE '_____$search%' THEN 6
WHEN email LIKE '_____$search%' THEN 6
WHEN phone LIKE '_____$search%' THEN 6
WHEN name LIKE '______$search%' THEN 7
WHEN email LIKE '______$search%' THEN 7
WHEN phone LIKE '______$search%' THEN 7
WHEN name LIKE '_______$search%' THEN 8
WHEN email LIKE '_______$search%' THEN 8
WHEN phone LIKE '_______$search%' THEN 8
WHEN name LIKE '________$search%' THEN 9
WHEN email LIKE '________$search%' THEN 9
WHEN phone LIKE '________$search%' THEN 9
WHEN name LIKE '_________$search%' THEN 10
WHEN email LIKE '_________$search%' THEN 10
WHEN phone LIKE '_________$search%' THEN 10
WHEN name LIKE '__________$search%' THEN 11
WHEN email LIKE '__________$search%' THEN 11
WHEN phone LIKE '__________$search%' THEN 11
WHEN name LIKE '___________$search%' THEN 12
WHEN email LIKE '___________$search%' THEN 12
WHEN phone LIKE '___________$search%' THEN 12 END, name ASC LIMIT $from,$limit;
            ");
    return json_encode($result);
    }




public function add_classes(Request $request){
    $title = $request->get("title");
    $link = $request->get("link");
    $subject = $request->get("subject");
    $duration = $request->get("duration");
    $description = $request->get("description");
    $timezone = $request->get("timezone");
    $time = $request->get("time");
    $date = $request->get("date");
    $teacher = $request->get("teacher");
    $student = $request->get("student");
    $guest = $request->get("guest");
    $repeat = $request->get("repeat");
    if (empty($guest)) {
        $guest = "";
    }
    if (empty($repeat)) {
        $repeat = "";
    }
    date_default_timezone_set($timezone);
    $data = array(
        "title" => $title,
        "link" => $link,
        "duration" => $duration,
        "description" => $description,
        "time" => $time,
        "date" => $date,
        "timezone" => $timezone,
        "teacher" => $teacher,
        "student" => $student,
        "guest" => $guest,
        "admin" => Auth::user()->name,
        "repeat" => $repeat );

    Mail::to($student)->send(New email($data));
    Mail::to($teacher)->send(New email($data));

$course = new course;
$course->title= $title;
$course->link= $link;
$course->subject= $subject;
$course->duration= $duration;
$course->description= $description;
$course->timezone= $timezone;
$course->starting= date("Y-m-d H:i:s",strtotime($date." ".$time.":00"));
$course->student= $student;
$course->teacher= $teacher;
$course->title= $title;
$g1 = "";
$g2 = "";
$ras = time().rand();
if ($guest!="") {
    $gu = explode(",", $guest);
    foreach ($gu as $key => $g) {
    $data = array(
        "title" => $title,
        "link" => $link,
        "duration" => $duration,
        "description" => $description,
        "time" => $time,
        "date" => $date,
        "timezone" => $timezone,
        "teacher" => $teacher,
        "student" => $student,
        "guest" => $guest,
        "accept" => "http://localhost/school/accept/$ras/".$key,
        "admin" => Auth::user()->name,
        "repeat" => $repeat );

       $g1.=",".$g; 
       $g2.=",0"; 
    Mail::to($g)->send(New email($data));
    }
}
$course->guest=$g1;
$course->guest_active= $g2;
$m1 = User::where("email","=",$teacher)->get();
$m2 = User::where("email","=",$student)->get();
$course->t_id= $m1[0]->id;
$course->s_id= $m2[0]->id;
$course->ras= $ras;
$course->repeat= $repeat;
if ($course->save()) {
    $doe= strtotime($date." ".$time.":00");
    date_default_timezone_set($m2[0]->timezone);
    $dt = date("Y-m-d H:i:s",$doe);
$date = date("Y-m-d", $doe);
$time = date("h:ia", $doe);
    $content = "<b>".Auth::user()->name."</b> added a class for you. <br> <b>".$title."</b><br>"."<p>$description</p><br> Class Duration: $duration <br>Class Link: <a href='$link'>$link</a> <br>Class Starting at: $date <br>Class Time: $time <br>Repeat:".($repeat=='' ? "No Repeat" : substr($repeat,1))." <br>guests: ".($guest=='' ? "No Guests" : $guest)." <br>Assigned Teacher: ".$m1[0]->name."<br>Students name: ".$m2[0]->name;


    $this->send($m1[0]->id, $content);
    $this->send($m2[0]->id, $content);
    $this->send("Admin", $content);
    return "Successfuly Added Class";
}
}
public function send($user, $content){
     $notification = new notification;
    $notification->user =$user;
    $notification->content = $content;
    if ($user!="Admin") {
    date_default_timezone_set(User::find($user)->timezone);
    }else{
    date_default_timezone_set(Auth::user()->timezone);
    }
    $notification->time = date("Y-m-d h:ia");
    $notification->read = 0;
    $notification->save();
    return;
}

public function notification(){
    return view("admin.notification");
}

public function accept($class, $index){
    if ($classes = course::where("ras","=",$class)->first()) {
        $handle = $classes->guest_active;
        $handles = $classes->guest;
        $handle =  explode(",", substr($handle, 1));
        $handles =  explode(",", substr($handles, 1));
        $handle[$index] = 1;
        $data = ",".implode(",", $handle);
        $classes->guest_active=$data;
        if ($classes->save()) {
            $this->send($classes->t_id,$handles[$index]." has accepted the guest request for ". $classes->title);
            $this->send($classes->s_id,$handles[$index]." has accepted the guest request for ". $classes->title);
            $this->send("Admin",$handles[$index]." has accepted the guest request for ". $classes->title);
    $msg = __("Thank you for accepting the guest Request.");   
        }else{

    $msg = __("Sorry failed to proccess the request.");   
        }
    }else{
    $msg = __("Sorry failed to find the class.");   
    }
    return view("accept_class",["msg"=>$msg]);
}

}
