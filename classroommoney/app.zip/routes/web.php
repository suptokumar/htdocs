<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get("/login",'mainct@login');
Route::post("/login",'mainct@logined');
Route::get("/logout",'mainct@logout');
Route::get("/register",'mainct@register');
Route::post("/register",'mainct@registered');
Route::post("/user_get",'mainct@user_get');
Route::post("/update",'mainct@update');
Route::post("/add_class",'mainct@add_classes');
Route::get("/details/{id}",'mainct@details');
Route::get("/accept/{class}/{index}",'mainct@accept');
Route::get('/notifications', 'mainct@notification');  
Route::post('/notifications', 'mainct@notifications');  
Route::get('/delete_noti', 'mainct@delete_noti');  

Route::group(['middleware' => 'login'], function() {
Route::get('/', 'mainct@index');

Route::group(['prefix' => 'admin','middleware' => 'admin'], function() {
Route::get('/', 'mainct@index');
Route::get('/users', 'mainct@users');  
Route::get('/user_list', 'mainct@user_list');  
Route::post('/user_list', 'mainct@user_list');  
Route::post('/block', 'mainct@block');  
Route::get('/manage_class', 'mainct@manage_class');  
Route::post('/manage_class', 'mainct@get_classes');  
Route::get('/settings', 'mainct@settings');  
Route::get('/payment', 'mainct@payment');  
Route::get('/add_class', 'mainct@add_class');  
});

Route::group(['prefix' => 'student','middleware' => 'student'], function() {
Route::get('/', 'mainct@index');
Route::get('/settings', 'mainct@settings');  
Route::get('/create_client', 'mainct@create_client');  
Route::post('/create_client', 'mainct@create_clients');  
});



Route::group(['prefix' => 'teacher','middleware' => 'teacher'], function() {
Route::get('/', 'mainct@index');
Route::get('/settings', 'mainct@settings');  
});
});

