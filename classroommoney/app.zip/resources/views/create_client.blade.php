@extends("layout.app")
@section("title","Create Client | School management software")
@section("active","settings")
@section("content")
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
}
</style>
 <article>

<form style="width: 90%; margin: 0 auto;" action="{{ url('/student/create_client') }}" method="POST" enctype="multipart/form-data"><br>
	<h3 style="text-align: center;">Create Client</h3>
			@if ($message = session("message"))
	<div class="alert alert-danger" role="alert">
  {{$message}}
</div>
@endif
@if ($success = session("success"))
	<div class="alert alert-success" role="alert">
  {{$success}}
</div>
@endif

 <div class="form-group">
    <label for="exampleInputEmail1">{{__('Client\'s Full Name')}}</label>
    <input type="text" class="form-control" id="name" name="name"  value="{{ old("name") }}" required aria-describedby="emailHelp" placeholder="Enter Full Name">
  </div>
<input type="hidden" name="id"  value="{{ Auth::user()->id }}">
@csrf
  <div class="form-group">
    <label for="exampleInputEmail1">{{__('Client\'s Email address')}}</label>
    <input type="email" class="form-control" id="email" required="" name="email" aria-describedby="emailHelp"    value="{{ old("email") }}" placeholder="Enter email">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">{{__('Client\'s Phone number')}}</label>
    <input type="text" class="form-control" id="phone" required="" name="phone" aria-describedby="emailHelp"     value="{{ old("phone") }}" placeholder="Enter phone number">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">{{__('Payment Method')}}</label>
    <select class="form-control" id="payment" required="" name="payment">
    	<option value="PayPal">PayPal</option>
    	<option value="Ria">Ria</option>
    	<option value="Western Union">Western Union</option>
    	<option value="Bank Account">Bank Account</option>
    	<option value="Others">Others</option>
    </select>
  </div>

 
  <div style="padding: 10px; overflow: hidden">
  <button type="submit" class="btn btn-success" style="float: right;">Save</button>
  </div>
</form>


 </article>
@endsection

@section("script")

@endsection