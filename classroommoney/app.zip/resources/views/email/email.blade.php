<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>{{ $data['title'] }}</title>
</head>
<body style="max-width: 450px; border: 1px solid #ccc; padding: 10px;">
	<h2>{{ $data['title'] }}</h2>
	<p>{{ $data['description'] }}</p>
</body>
</html>