<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo e(Auth::user()->type==4?"Tutor":(Auth::user()->type==2?"Teacher":"Student")); ?> | classroommoney</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="<?php echo e(asset('/public/js/main.js')); ?>"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

    <script src="<?php echo e(asset('/public/js/jquery.js')); ?>"></script>

    <link rel="stylesheet" href="<?php echo e(asset('/public/css/dash.css?d')); ?>">

</head>
<body>
<div class="container">

<div class="all_payments" style="width: 100%">
  
</div>
<div class="section">
<a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Home</a>

<form style="background: white; padding: 20px; width: 90%; margin: 100px auto; border: 1px solid #ccc;" action="<?php echo e(url('/rummba')); ?>" method="POST" enctype="multipart/form-data">

  <?php echo csrf_field(); ?>
  
  <h2>Books</h2>
  <hr>

  <?php if($message = session("message")): ?>
  <div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>

<?php if($success = session("success")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="name">Grade <span style="color: red">*</span></label>
      <select name="grade" id="grade" class="form-control">
        <option value="7">7th</option>
        <option value="8">8th</option>
        <option value="9">9th</option>
        <option value="10">10th</option>
        <option value="11">11th</option>
        <option value="12">12th</option>
      </select>
    </div>
    <div class="form-group col-md-6">
      <label for="title">Title <span style="color: red">*</span></label>
      <input type="text" class="form-control" required=""  id="title" name="title">
    </div>
    </div>
      <div class="form-row">

    <div class="form-group col-md-6">
      <label for="link">File Link <span style="color: red">*</span></label>
      <input type="text" class="form-control" required=""  id="link" name="link">
    </div>
    <div class="form-group col-md-6">
      <label for="thumb">Book upload <span style="color: red">*</span></label>
      <input type="file" class="form-control" required=""  id="thumb" name="thumb">
    </div>
      </div>
      <div class="form-row">
    <div class="form-group col-md-6">
      <label for="description">Description <span style="color: red">*</span></label>
      <input type="text" class="form-control" required=""  id="description" name="description">
    </div>
  </div>
    <button type="submit" class="btn btn-primary">Add</button>

</form>


</div>
<form action="" method="GET">
  <input type="text" name="s" placeholder="search">
  <select name="mode" id="">
    <option value="">-- SELECT STATUS --</option>
    <option value="1">Published</option>
    <option value="2">Pending</option>
  </select><input type="submit" value="search"></form>
<style>
  .book {
  width: 300px;
  float: left;
  height: 530px;
  overflow: hidden;
  border: 1px solid #ccc;
  padding: 1%;
  margin: 1%;
}
.book .imgs1 {
  width: 100%;
  height: 300px;
}
</style>
<div class="mainct">
  <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="book a<?php echo e($book->id); ?>">
      <button class="btn btn-danger" onclick="delte_it(<?php echo e($book->id); ?>,this)">Delete</button>
            <?php if($book->mode==1): ?>
      <button class="btn btn-success" onclick="addq(<?php echo e($book->id); ?>,this)">Add question</button>
      <?php endif; ?>
      <img src="<?php echo e(url('/public/image/'.$book->thumb)); ?>" class="imgs1" alt="">
      <h3><?php echo e($book->title); ?></h3>
      <p><?php echo e($book->description); ?></p>
      <p>Status: <?php echo e($book->mode==2?"Pending":"Published"); ?></p>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<script>
  function delte_it(id,t){
    if (confirm("Are you sure you want to delete it?")) {
      $.ajax({
        url: '<?php echo e(url('/delteanoe')); ?>',
        type: 'POST',
        data: {id:id,_token:'<?php echo e(csrf_token()); ?>'},
      })
      .done(function(data) {
        $(t).html(data);
        $(".a"+t).css('background', '#FFD4D4');
      });
      
    }
  }

    function addq(id,t){
window.location = '<?php echo e(url('/questions/')); ?>/'+id;
 }
</script>
<?php /**PATH C:\xampp\htdocs\classroommoney\resources\views/bookcreater.blade.php ENDPATH**/ ?>