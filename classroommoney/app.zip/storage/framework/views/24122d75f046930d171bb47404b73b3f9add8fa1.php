<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Student | classroommoney</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="<?php echo e(asset('/public/js/main.js')); ?>"></script>

    <script src="<?php echo e(asset('/public/js/jquery.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('/public/css/dash.css?d')); ?>">
</head>
<body>
<?php if(Auth::user()->type==3): ?>
<div class="topnav" id="myTopnav">
  <a href="<?php echo e(url('/')); ?>" class="active">Classroom Money</a>
  <a href="<?php echo e(url('/student/mymarksheet')); ?>">Marksheet</a>
  <a href="<?php echo e(url('/student/myteachers')); ?>">Teachers</a>
  <div class="dropdown">
    <button class="dropbtn">Account 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="<?php echo e(url('/invest')); ?>">Invest</a>
      <a href="<?php echo e(url('/balance')); ?>">My balance</a>
      <a href="<?php echo e(url('/earning')); ?>">Earning Records</a>
            <a href="<?php echo e(url('/student/teach')); ?>">My Teachers</a>

      <a href="<?php echo e(url('/settings')); ?>">Settings</a>
    </div>
  </div> 
  <a href="<?php echo e(url('/logout')); ?>">Logout</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
<?php endif; ?>
<?php if(Auth::user()->type==2): ?>
  <div class="topnav" id="myTopnav">
  <a href="<?php echo e(url('/')); ?>">Classroom Money</a>
  <a href="<?php echo e(url('/teacher/mymarksheet')); ?>" class="active">Marksheet</a>
  <a href="<?php echo e(url('/teacher/mystudents')); ?>">Students</a>
  <a href="<?php echo e(url('/teacher/requests')); ?>">Requests</a>
  <a href="<?php echo e(url('/settings')); ?>">Settings</a>
  <a href="<?php echo e(url('/logout')); ?>">Logout</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
<?php endif; ?>

<div>

<div class="dash">

<?php if(Auth::user()->type==2): ?>


<form style="background: white; padding: 20px; width: 90%; margin: 100px auto; border: 1px solid #ccc;" action="<?php echo e(url('/add_marks')); ?>" method="POST" enctype="multipart/form-data">

  <?php echo csrf_field(); ?>
  
  <h2>Account Settings</h2>
  <hr>

  <?php if($message = session("message")): ?>
  <div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>

<?php if($success = session("success")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>

  <h4 style="text-align: center">Personal Details</h4>
  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="subject">Subject<span style="color: red">*</span></label>
      <input type="text" class="form-control" readonly="" id="subject" name="subject" value="<?php echo e($user->subject); ?>">
    </div>
    <div class="form-group col-md-4">
      <label for="mark">Marks <span style="color: red">*</span></label>
      <input type="text" class="form-control" required=""  id="mark" name="mark" placeholder="Marks">
    </div>
    <div class="form-group col-md-4">
      <label for="attend">Miss Attentends <span style="color: red">*</span></label>
      <input type="text" class="form-control" required="" id="attend" name="attend" placeholder="Attentends">
    </div>
<input type="hidden" name="student" value="<?php echo e($id); ?>">

  <button type="submit" class="btn btn-primary">Add</button>
</form>






<?php endif; ?>

</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\classroommoney\resources\views/add_mark.blade.php ENDPATH**/ ?>