<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Marksheet | classroommoney</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="<?php echo e(asset('/public/js/main.js')); ?>"></script>

    <script src="<?php echo e(asset('/public/js/jquery.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('/public/css/dash.css?d')); ?>">
</head>
<body>
<div class="topnav" id="myTopnav">
  <a href="<?php echo e(url('/')); ?>">Classroom Money</a>
  <a href="<?php echo e(url('/student/mymarksheet')); ?>">Marksheet</a>
  <a href="<?php echo e(url('/student/myteachers')); ?>">Teachers</a>
    <a href="<?php echo e(url('/student/tutors')); ?>">Tutors</a>
  <a href="<?php echo e(url('/student/library')); ?>" class="active">Library</a>

  <div class="dropdown">
    <button class="dropbtn">Account 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="<?php echo e(url('/invest')); ?>">Fee submission</a>
      <a href="<?php echo e(url('/balance')); ?>">My balance</a>
      <a href="<?php echo e(url('/earning')); ?>">Earning Records</a>
      <a href="<?php echo e(url('/student/teach')); ?>">My Teachers</a>
      <a href="<?php echo e(url('/settings')); ?>">Settings</a>
    </div>
  </div> 
  <a href="<?php echo e(url('/logout')); ?>">Logout</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
<div style="background:#D0E8FF;padding:20px;">
<div style=" width: 100%" class="row">
  <div class="rk col-sm-6" style="float: right;">
<form action="" method="GET">
    Search <input type="search" name="s" <?php if(isset($_GET['s'])): ?>
      value="<?php echo e($_GET['s']); ?>"
    <?php endif; ?> id="snod410" autocomplete="off" style="padding: 10px; width: 60%; border: 1px solid #ccc; outline: none;" placeholder="Search"><input type="submit" style="padding: 10px; display: none" value="search">

    <a href="<?php echo e(url('/student/mybooks')); ?>" class="btn btn-primary float-right">My Books</a>
</form>
  </div>
</div>
</div>
<div>
<input type="hidden" value="<?php echo e(csrf_token()); ?>" id="csrf">

<div class="all_payments" style="width: 100%">

<style>
  .book {
  width: 300px;
  float: left;
  height: 530px;
  overflow: hidden;
  border: 1px solid #ccc;
  padding: 1%;
  margin: 1%;
}
.book .imgs1 {
  width: 100%;
  height: 300px;
}
</style>
<div class="mainct">
  <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="book a<?php echo e($book->id); ?>">
      <button class="btn btn-primary float-right" onclick="delte_it(<?php echo e($book->id); ?>,this)">Read & Earn</button>
      <img src="<?php echo e(url('/public/image/'.$book->thumb)); ?>" class="imgs1" alt="">
      <h3><?php echo e($book->title); ?></h3>
      <p><?php echo e($book->description); ?></p>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<script>
  function delte_it(id,t){
      $.ajax({
        url: '<?php echo e(url('/request_perchage')); ?>',
        type: 'POST',
        data: {id:id,_token:'<?php echo e(csrf_token()); ?>'},
      })
      .done(function(data) {
        $(t).html(data);
        $(".a"+t).css('background', '#FFD4D4');
      });
      
    }
</script>
  
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\classroommoney\resources\views/library.blade.php ENDPATH**/ ?>