
<?php $__env->startSection("title","Create Client | School management software"); ?>
<?php $__env->startSection("active","settings"); ?>
<?php $__env->startSection("content"); ?>
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
}
</style>
 <article>

<form style="width: 90%; margin: 0 auto;" action="<?php echo e(url('/update_client')); ?>" method="POST" enctype="multipart/form-data"><br>
	<h3 style="text-align: center;">Edit Client</h3>
			<?php if($message = session("message")): ?>
	<div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
	<div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>

<?php if($new_client = session("new_client")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($new_client); ?>

</div>
<?php endif; ?>

 <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Full Name')); ?></label>
    <input type="text" class="form-control" id="name" name="name"  value="<?php echo e($client->name); ?>" required aria-describedby="emailHelp" placeholder="Enter Full Name">
  </div>
<input type="hidden" name="id"  value="<?php echo e($client->id); ?>">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Email address')); ?></label>
    <input type="email" class="form-control" id="email" required="" name="email" aria-describedby="emailHelp"    value="<?php echo e($client->email); ?>" placeholder="Enter email">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Phone number')); ?></label>
    <input type="text" class="form-control" id="phone" required="" name="phone" aria-describedby="emailHelp"     value="<?php echo e($client->phone); ?>" placeholder="Enter phone number">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Hour Rate')); ?></label>
    <input type="number" class="form-control" id="rate" required="" name="rate" aria-describedby="emailHelp" value="<?php echo e($client->rate); ?>" placeholder="Enter Hourly Rate">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Payment in USD')); ?></label>
    <input type="number" class="form-control" id="payment_usd" required="" name="payment_usd" aria-describedby="emailHelp" value="<?php echo e($client->payment_usd); ?>" placeholder="payment in usd">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Payment Hours (min)')); ?></label>
    <input type="number" class="form-control" id="hours" required="" name="hours" aria-describedby="emailHelp" value="<?php echo e($client->hours); ?>" placeholder="in minute">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Last Payment Date')); ?></label>
    <input type="date" class="form-control" id="last_payment_date" required="" name="last_payment_date" aria-describedby="emailHelp" value="<?php echo e($client->last_payment_date); ?>" placeholder="payment date">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Client\'s Invoice')); ?></label>
    <input type="number" class="form-control" id="invoice_number" required="" name="invoice_number" aria-describedby="emailHelp" value="<?php echo e($client->invoice_number); ?>" placeholder="Enter Hourly Rate">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Payment Method')); ?></label>
    <select class="form-control" id="payment" required="" name="payment">
    	<option value="PayPal" <?php echo e($client->payment=='PayPal'?"selected":""); ?>>PayPal</option>
    	<option value="Ria" <?php echo e($client->payment=='Ria'?"selected":""); ?>>Ria</option>
    	<option value="Western Union" <?php echo e($client->payment=='Western Union'?"selected":""); ?>>Western Union</option>
    	<option value="Bank Account" <?php echo e($client->payment=='Bank Account'?"selected":""); ?>>Bank Account</option>
    	<option value="Others" <?php echo e($client->payment=='Others'?"selected":""); ?>>Others</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Payment Plan')); ?></label>
    <select class="form-control" id="payment_plan" required="" name="payment_plan">
      <option value="Advance" <?php echo e($client->payment_plan=='Advance'?"selected":""); ?>>Advance</option>
      <option value="In arrears" <?php echo e($client->payment_plan=='In arrears'?"selected":""); ?>>In arrears</option>
    </select>
  </div>

 
  <div style="padding: 10px; overflow: hidden">
  <button type="submit" class="btn btn-success" style="float: right;">Save</button>
  </div>
</form>


 </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/admin/client_edit.blade.php ENDPATH**/ ?>