<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo e($data['title']); ?></title>
</head>
<body style="max-width: 450px; border: 1px solid #ccc; padding: 10px;">
	<h2><?php echo e($data['title']); ?></h2>
	<p><?php echo e($data['description']); ?></p>
	<pre>
Class Duration: <?php echo e($data['duration']); ?>

Class Starting at: <?php echo e($data['time']); ?> <?php echo e($data['date']); ?> (<?php echo e($data['timezone']); ?>)
Assigned Teacher: <?php echo e($data['teacher']); ?>

Student's email: <?php echo e($data['student']); ?>

Class Link: <a href="<?php echo e($data['link']); ?>"><?php echo e($data['link']); ?></a>
Guests: <?php echo e($data['guest']); ?>

Repeat: <?php echo e($data['repeat']=='' ? "No Repeat" : str_replace(",", " ", $data['repeat'])); ?>

	</pre>
		<?php if(isset($data['accept'])): ?>
Accept Guest Request: <a href="<?php echo e($data['accept']); ?>" style="border: 1px solid #ccc; padding: 10px 20px; display: block; text-decoration: none; background: green; color: white; max-width: 100px; text-align: center; margin: 0px auto;">Click Here To Accept</a>
		<?php endif; ?>

	With Best Regards, <br>
	<?php echo e($data['admin']); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\school\resources\views/email/email.blade.php ENDPATH**/ ?>