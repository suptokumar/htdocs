=== Advanced iFrame custom folder ===
Contributors: mdempfle
Donate link: http://www.tinywebgallery.com
Tags: iframe, embed, resize, zoom, content, advanced, shortcode, modify css, widget 
Requires at least: 3.2
Tested up to: 5.5.3
Stable tag: 1.0
Requires PHP: 5.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is no real plugin! This is the folder of advanced iframe where custom files are stored. It is not part of the main plugin because updating the main plugin will always make a fresh install! Only remove this if you completely want to remove Advanced iFrame (pro). Advanced iframe uses the internal plugin editor to modify custom files and since Wordpress 4.9.3 this is only possible if the files are in a "real" plugin folder. You don't need to activate this "plugin". 