var domain_advanced_iframe = '../';
var iframe_id="advanced_iframe";
var updateIframeHeight = "true"; 
var keepOverflowHidden = "false";
var hide_page_until_loaded_external = "true";    
var onload_show_element_only = "#iframe-right"; 
var iframe_content_id = "#iframe-right";
var iframe_content_styles = "float:none;height:auto;color:#ff0000;";
var resize_on_element_resize = "#iframe-right";
var resize_on_element_resize_delay = "50";
// this is used here that the example works out of the box everywhere!
// if you set this to false you need to set post_message_domain instead!
var domainMultisite = 'true';