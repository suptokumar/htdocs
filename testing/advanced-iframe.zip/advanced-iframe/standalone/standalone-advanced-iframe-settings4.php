<?php

/** This are the options for the iframe. See all possible options in the documentation 
 *  or standalone-advanced-iframe4.php 
 */
$iframeStandaloneOptions = array(
   'id' => 'advanced_iframe',
   'name' => 'advanced_iframe',
   'scrolling' => 'no',
   'width' => '950',
   'height' => '200px',
   'src' => '../example/example_standalone.html', 
);    
?>