<?php
defined('_VALID_AI') or die('Direct Access to this location is not allowed.');

      aiPostboxOpen("id-help-faq", "FAQ", $closedArray);  	
	  _e('The FAQ is not included in the plugin directly as it is updated frequently on the website.' , 'advanced-iframe'); ?></p><p>
      <a href="//www.tinywebgallery.com/blog/advanced-iframe/advanced-iframe-faq" target="_blank" id="faq" class="button-primary"><?php _e('Go to the FAQ' , 'advanced-iframe'); ?></a>
<?php	
	aiPostboxClose();	
?>