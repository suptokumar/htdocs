<?php
defined('_VALID_AI') or die('Direct Access to this location is not allowed.');

      aiPostboxOpen("id-help-forum", "Forum", $closedArray); 
	  _e('Please use the forum for support. Make sure to enable the "Check shortcode" on the options tab first as this maybe already show you which setting is not valid!' , 'advanced-iframe'); ?></p><p>
      <a href="https://www.tinywebgallery.com/en/forum.php" target="_blank" id="faq" class="button-primary"><?php _e('Go to the forum' , 'advanced-iframe'); ?></a>
<?php	
	aiPostboxClose();	
?>	  
