
<?php $__env->startSection("title","Payments | School management software"); ?>
<?php $__env->startSection("active","payment"); ?>
<?php $__env->startSection("content"); ?>
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
}
</style>
 <article>


<h3 style="text-align: center; margin: 10px">Create Payment</h3>
<article style="padding: 10px;">
	<form action="<?php echo e(url('/admin/payments')); ?>" method="POST" id="eonoasdf100d">
		<?php if($message = session("message")): ?>
	<div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
	<div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>


		<?php echo csrf_field(); ?>
<div class='row'>
   <div class="form-group col-sm-3">
   		
    <label for="exampleInputEmail1"><?php echo e(__('Payment Type')); ?></label>
		<select class="form-control" name="type"  id="type" required="">
			<option value="1">Student</option>
			<option value="2">Client</option>
		</select>
  	</div>

  	<div class="form-group col-sm-3">
    <label for="exampleInputEmail1"><?php echo e(__('Payment Date')); ?></label>
		<input class="form-control" name="date" required="" type="date">
  	</div>
  	
  	<div class="form-group col-sm-3">
    <label for="exampleInputEmail1"><?php echo e(__('Client ID or Student\'s Mail')); ?></label>
		<input class="form-control" name="client" required="" type="text">
  	</div>
  	  	
  	<div class="form-group col-sm-3">
    <label for="exampleInputEmail1"><?php echo e(__('Invoice')); ?></label>
		<input class="form-control" name="invoice" type="text">
  	</div>
  </div>
  <div class='row'>

  	<div class="form-group col-sm-3">
    <label for="exampleInputEmail1"><?php echo e(__('Fees')); ?></label>
		<input class="form-control" name="fees" type="text">
  	</div>
  	  	<div class="form-group col-sm-3">
    <label for="exampleInputEmail1"><?php echo e(__('Transfer Fees')); ?></label>
		<input class="form-control" name="transfer_fees" type="text">
  	</div>
  	  	  	<div class="form-group col-sm-3">
    <label for="exampleInputEmail1"><?php echo e(__('Extra Payment')); ?></label>
		<input class="form-control" name="extra_payment" type="text">
  	</div>
  	
  	<div class="form-group col-sm-3">
    <label for="exampleInputEmail1"><?php echo e(__('Purchased Hours')); ?></label>
		<input class="form-control" name="hours" required="" type="text">
  	</div>
  	
  	</div>

    <div class="form-group">
    	<input type="hidden" name="refil" value="1">
        <button type="submit" class="btn btn-primary btn-block"> Complete Payment  </button>
    </div> <!-- form-group// -->      
</form>
</article>
<div class="search" style="width: 100%; padding: 2%; overflow: hidden">
	<div class="rk" style="float: right; align-items: center;">
		Search <input type="search" id="snod410" autocomplete="off" onkeyup="get_payments(1)" style="padding: 10px; border: 1px solid #ccc; outline: none;" placeholder="Date">
	</div>
	<div class="dk">
<input type="hidden" value="<?php echo e(csrf_token()); ?>" id="csrf">
	</div>
</div>
<div class="all_payments" style="width: 100%">
	
</div>


</article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('/public/js/admin.js?')); ?>"></script>
<script>
	$(document).ready(function() {
		get_payments(1);
	});
	function dp_fun(page){
		get_payments(page);

	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\platform\resources\views/admin/payment.blade.php ENDPATH**/ ?>