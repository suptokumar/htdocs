    <!--<div class="col-sm-10">-->
    <!--	@php-->
    <!--		function mg_co($val,$arrs){-->
    <!--			$arr = explode(",",$arrs);-->
    <!--			if(in_array($val, $arr)){-->
    <!--				echo "selected";-->
    <!--			}-->
    <!--		}-->
    <!--	@endphp-->
    <!--  <div class="days">-->
    <!--    <input type="button" class="day_tog day_ml {{ mg_co("Sunday",$course->repeat) }}" id="Sunday"  value="Sunday">-->
    <!--    <input type="button" class="day_tog day_ml {{ mg_co("Monday",$course->repeat) }}" id="Monday"  value="Monday">-->
    <!--    <input type="button" class="day_tog day_ml {{ mg_co("Tuesday",$course->repeat) }}" id="Tuesday" value="Tuesday">-->
    <!--    <input type="button" class="day_tog day_ml {{ mg_co("Wednesday",$course->repeat) }}" id="Wednesday"  value="Wednesday">-->
    <!--    <input type="button" class="day_tog day_ml {{ mg_co("Thursday",$course->repeat) }}" id="Thursday" value="Thursday">-->
    <!--    <input type="button" class="day_tog day_ml {{ mg_co("Friday",$course->repeat) }}" id="Friday"  value="Friday">-->
    <!--    <input type="button" class="day_tog day_ml {{ mg_co("Saturday",$course->repeat) }}" id="Saturday" value="Saturday">-->
    <!--    <br>-->
    <!--  </div>-->
    <!--</div>-->