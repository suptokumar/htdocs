@extends("layout.app")
@section("title","Admin Portal")
@section("active","products")
@section("content")
 <article>This is a theme that I will use</article>
    <article>This is a theme that I will use</article>
    <article>This is a theme that I will use</article>
    <article>This is a theme that I will use</article>
@endsection