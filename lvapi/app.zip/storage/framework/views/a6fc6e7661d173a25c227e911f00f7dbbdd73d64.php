
<?php $__env->startSection("title","Admin Portal"); ?>
<?php $__env->startSection("active","products"); ?>
<?php $__env->startSection("content"); ?>
 <article>This is a theme that I will use</article>
    <article>This is a theme that I will use</article>
    <article>This is a theme that I will use</article>
    <article>This is a theme that I will use</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lvapi\resources\views/index.blade.php ENDPATH**/ ?>