
<?php $__env->startSection("title","Admin Portal"); ?>
<?php $__env->startSection("active","users"); ?>
<?php $__env->startSection("content"); ?>
<article>
<header style="overflow: hidden;">
  <a href="<?php echo e(url('/admin/exchange')); ?>" class="btn btn-danger float-left">Exchange List</a>
  <a href="<?php echo e(url('/admin/addconfigure')); ?>" class="btn btn-success float-left">Add Exchange Type</a>
    <a href="<?php echo e(url('/admin/plan')); ?>" class="btn btn-info float-left">Add Plan</a>

</header>
<section class="gateway_view">
  <form action="<?php echo e(url('/admin/createapi/addexchangelist')); ?>" method="POST" enctype="multipart/form-data">

<br>
<?php if($message = session("message")): ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php endif; ?>

<?php if($success = session("success")): ?>
<div class="alert alert-success" role="alert">
<?php echo e($success); ?>

</div>
<?php endif; ?>


    <?php echo csrf_field(); ?>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="name">Exchange Name <span class="red">*</span></label>
      <input type="text" class="form-control" name="name" id="name" required="" placeholder="eg: Cricket">
    </div>
    <div class="form-group col-md-6">
      <label for="min_value">Exchange Minimum Bid Coins</label>
      <input type="number" class="form-control" name="min_value" for="min_value" placeholder="eg: 10">
    </div>
    
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="type">Select Type of Bidding Allowed <span class="red">*</span></label>
      <select class="form-control" required="" multiple="multiple" name="type[]" id="asdfeea">
        <?php $__currentLoopData = $configure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	<option value="<?php echo e($cg->id); ?>"><?php echo e($cg->text); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
<br>
      <label for="type">Select Plan <span class="red">*</span></label>
      <select class="form-control" required="" multiple="" id="awet" name="plan[]">
        <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($cg->id); ?>"><?php echo e($cg->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
<br>
      <label for="type">Exchange URL <span class="red">*</span></label>
      <input type="text" class="form-control" name="exchangeurl" for="exchangeurl" placeholder="eg: https://www.google.com">
    
    </div>
    
    <div class="form-group col-md-6">
      <label for="icon">Logo<br>
      <img src="<?php echo e(url('/public/logo/user.png')); ?>" id="blah" alt="Default Image" style="width: 150px; height: 135px; border-radius: 10px;"></label>
      <input type="file" class="form-control" style="display: none;" name="file" id="icon" placeholder="eg: Icon">
    </div>
  </div>
  <div class="cpnel">
    
  </div>
  <br>
  <div style="text-align: center;">
  <button type="submit" class="btn btn-primary">Create Exchange</button>
  </div>
</form>
</section>
</article>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<script>
  $(function(){

    $('#asdfeea').multiselect({

    // allows HTML content
    enableHTML: false,
       // CSS class of the multiselect button
    buttonClass: 'custom-select'
  });
    $('#awet').multiselect({

    // allows HTML content
    enableHTML: false,
       // CSS class of the multiselect button
    buttonClass: 'custom-select'
  });

  });
</script>
<style>
.page-content .grid > article:first-child {
    grid-column: 1 / -1;
    display: block;
}
.multiselect-native-select {
    width: 100%;
    display: block;
}
.form-check-label{
  color: black;
}
.btn-group, .btn-group-vertical{
  display: block !important;
}
.multiselect-container{
  width: 100%;
}
.custom-select{
  background: #242222 url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='4' height='5' viewBox='0 0 4 5'%3e%3cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3e%3c/svg%3e") no-repeat right .75rem center/8px 10px;
  color: #90979d;
}
</style>
<script>
  let imgInp = document.getElementById('icon');
  let blah = document.getElementById('blah');
  imgInp.onchange = evt => {
  const [file] = imgInp.files
  if (file) {
    blah.src = URL.createObjectURL(file)
  }
}
</script>
<script>
function accept(id,th){
  if (confirm("Accept?")) {
    $.ajax({
      url: '<?php echo e(url('/admin/acceptreader')); ?>',
      type: 'POST',
      data: {id: id,_token:"<?php echo e(csrf_token()); ?>"},
    })
    .done(function(data) {
      $(th).html(data);
    });
    
  }
}
function deletes(id,th){
  if (confirm("Delete?")) {
    $.ajax({
      url: '<?php echo e(url('/admin/deletesreader')); ?>',
      type: 'POST',
      data: {id: id,_token:"<?php echo e(csrf_token()); ?>"},
    })
    .done(function(data) {
      $(th).html(data);
    });
    
  }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lvapi\resources\views/admin/addexchange.blade.php ENDPATH**/ ?>