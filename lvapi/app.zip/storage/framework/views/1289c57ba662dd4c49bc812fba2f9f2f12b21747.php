
<?php $__env->startSection("title","Admin Portal"); ?>
<?php $__env->startSection("active","createid"); ?>
<?php $__env->startSection("content"); ?>
<article>
<header style="overflow: hidden;">
	<div class="row">
		<div class="col-4">
			<input onkeyup="load_user(1)" id="searches"  placeholder="Search" class="form-control">
		</div>
		<div class="col-4">
			<select onchange="load_user(1)" id="type" class="form-control">
				<option value="">--Status--</option>
				<option value="">All</option>
        		<option value="pending" selected="">pending</option>
        		<option value="approved">approved</option>
        		<option value="deleted">deleted</option>
			</select>
		</div>

	</div>
</header>
<section class="user_view">
	Here we  will  see the user  info

	Change username and password
	Status changing

</section>
</article>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<style>
.page-content .grid > article:first-child {
    grid-column: 1 / -1;
    display: block;
}
.card-view {
  margin:2px;
  padding: 5px;
  border: 1px solid #ccc;
  animation: .4s moving;
}
@keyframes  moving {
    from{
      margin-top: 30px;
    }
}
</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lvapi\resources\views/admin/actionid.blade.php ENDPATH**/ ?>