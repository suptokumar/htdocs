<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\models\mostview;
use \App\models\topnewcomertrack;
use \App\models\mostplayedtrack;
use \App\models\detailsload;
include 'simple_html_dom.php';
class soft extends Controller
{
    public function __construct()
    {

    }
    public function detailsload()
    {
    	echo '<body id="body"><style> *{background:black; color: white; font: 25px arial;}</style>';
	echo '<script src="'.url("public/src/assets/js/vendor/jquery-3.3.1.min.js").'"></script><script>

	// If you don\'t know when data comes, you can set an interval:
window.setInterval(function() {
  $("body,html").animate({
  	scrollTop: 1000000
  	},1000);
}, 1000);



</script>';
	$files = mostview::get();
	if(!$files){
		return redirect('mostview');
	}

	$ft = detailsload::get();
	foreach($ft as $kes=> $f)
	{
		$eon = detailsload::find($f->id);
		$eon->delete();
		echo "Deleted: ".$kes." <br>";
	}
	$j = 0;
	echo "Scrapping from web...";
	for($i = 0; $i<count($files); $i++){

if($file = file_get_html("https://www.1001tracklists.com".$files[$i]->link))
{
	foreach ($file->find(".bItm") as $key=> $bt)
	{
		echo "Index: ".$j."<br>";
		$j++;
		$titlelabel = $bt->find(".fontL .notranslate")?$bt->find(".fontL .notranslate")[0]->plaintext:"Undefined";

		$dj = $bt->find(".bCont .mt5 .mr10")?$bt->find(".bCont .mt5 .mr10")[0]->plaintext:($bt->find(".bCont .noMob")?$bt->find(".bCont .noMob")[0]->plaintext:"Undefined");
		
		$tb = explode('-',$titlelabel);
		if (isset($tb[0])) {
			$title = $tb[0];
		}else{
			$title = "Undefined";
		}
		if (isset($tb[1])) {
			$label = $tb[1];
		}else{
			$title = "Undefined";
		}

		$detailsload = new detailsload;
		$detailsload->view = $j;
		$detailsload->title = $titlelabel;
		$detailsload->label = '';
		$detailsload->dj = '';
		$detailsload->save();
		
	}
}

}

return redirect("mostviewdetails");
    }


    public function trackcrack()
    {

    		for($i = 1; $i<11; $i++){

if($file = file_get_html("https://www.1001tracklists.com/ajax/getmostviewedtls.php?mode=1&id=2&param=nc7&showRank=true&page=$i"))
{
	$file = json_decode($file, true);
	print_r($file['data']);
}
sleep(10);	// Sleeps 10 seconds

}
}


public function mostplay()
{
	for($i = 1; $i<11; $i++){

if($file = file_get_html("https://www.1001tracklists.com/ajax/getmostplayedtracks.php?mode=2&id=2&param=4w&showRank=true&page=$i"))
{
	$file = json_decode($file, true);
	print_r($file['data']);
}
sleep(10);	// Sleeps 10 seconds

}
    }

public function newtracker()
{
	for($i = 1; $i<6; $i++){

if($file = file_get_html("https://www.1001tracklists.com/ajax/getmostplayedtracks.php?mode=2&id=2&param=nc&showRank=true&page=$i"))
{
	$file = json_decode($file, true);
	print_r($file['data']);
}
sleep(10);	// Sleeps 10 seconds

}
}



public function tracklist()
{

	$check = mostview::orderBy("id","desc")->first();
if($check)
{
//set the frequency. 24 means every 24 hours
	if(strtotime(date("Y-m-d",strtotime($check->created_at)+7*24*3600))<time()){

	if($html = file_get_html(url("trackcrack"))){
		$array = mostview::get();
		foreach($array as $a)
		{
			$mostview = mostview::find($a->id);
			$mostview->delete();
		}
		foreach ($html->find(".ml5") as $key => $img) {
			$link = $img->find("a")[0]->href;
			$title = $img->find("a")[0]->innertext;
			$view = $img->find(".tlviews")[0]->innertext;
			$view = str_replace('<i class="fa fa-eye spr"></i>','',$view);
			$date = $img->find("span[title=tracklist date]")[0]->innertext;

			$mostview = new mostview;
			$mostview->link = $link;
			$mostview->title = $title;
			$mostview->view =$view;
			$mostview->date = $date;
			$mostview->save(); 
		}
	}
	}
}else{
	if($html = file_get_html(url("trackcrack"))){
		$array = mostview::get();
		foreach($array as $a)
		{
			$mostview = mostview::find($a->id);
			$mostview->delete();
		}
		foreach ($html->find(".ml5") as $key => $img) {
			$link = $img->find("a")[0]->href;
			$title = $img->find("a")[0]->innertext;
			$view = $img->find(".tlviews")[0]->innertext;
			$view = str_replace('<i class="fa fa-eye spr"></i>','',$view);
			$date = $img->find("span[title=tracklist date]")[0]->innertext;

			$mostview = new mostview;
			$mostview->link = $link;
			$mostview->title = $title;
			$mostview->view =$view;
			$mostview->date = $date;
			$mostview->save(); 
			

		}
	}
}
		$array = mostview::get();
		foreach($array as $key => $a)
		{
			$array[$key]->date = date("d-m-Y", strtotime($a->date));
			$array[$key]->link = 'https://www.1001tracklists.com'.$a->link;
		}
return view("tracklist",["array"=>$array]);
}

public function mostplayed()
{

$check = mostplayedtrack::orderBy("id","desc")->first();
if($check)
{
//set the frequency. 24 means every 24 hours
	if(strtotime(date("Y-m-d",strtotime($check->created_at)+24*3600))<time()){

	if($html = file_get_html(url("mostplay"))){
		$array = mostplayedtrack::get();
		foreach($array as $a)
		{
			$mostplayedtrack = mostplayedtrack::find($a->id);
			$mostplayedtrack->delete();
		}
		foreach ($html->find(".ml2") as $key => $img) {
			$link = $img->find(".spr")?$img->find(".spr")[0]->href:"Undefined";
			$title = $img->find(".spr")?$img->find(".spr")[0]->innertext:"Undefined";
			$label = $img->find(".tracklabel")?$img->find(".tracklabel")[0]->innertext:"Undefined";
			$dj = $img->find(".playc")?$img->find(".playc")[0]->plaintext:"Undefined";
			// $dj = str_replace('<i class="fa fa-play-circle-o spr"></i>','',$dj);

			$mostplayedtrack = new mostplayedtrack;
			$mostplayedtrack->view = $link;
			$mostplayedtrack->title = $title;
			$mostplayedtrack->label =$label;
			$mostplayedtrack->dj = $dj;
			$mostplayedtrack->save(); 
		}
	}
	}
}else{
	if($html = file_get_html(url("mostplay"))){
		$array = mostplayedtrack::get();
		foreach($array as $a)
		{
			$mostplayedtrack = mostplayedtrack::find($a->id);
			$mostplayedtrack->delete();
		}
		foreach ($html->find(".ml2") as $key => $img) {

			$link = $img->find(".spr")?$img->find(".spr")[0]->href:"Undefined";
			$title = $img->find(".spr")?$img->find(".spr")[0]->innertext:"Undefined";
			$label = $img->find(".tracklabel")?$img->find(".tracklabel")[0]->innertext:"Undefined";
			$dj = $img->find(".playc")?$img->find(".playc")[0]->plaintext:"Undefined";
			// $dj = str_replace('<i class="fa fa-play-circle-o spr"></i>','',$dj);

			$mostplayedtrack = new mostplayedtrack;
			$mostplayedtrack->view = $link;
			$mostplayedtrack->title = $title;
			$mostplayedtrack->label =$label;
			$mostplayedtrack->dj = $dj;
			$mostplayedtrack->save(); 
		}
	}
}
		$array = mostplayedtrack::get();
		foreach($array as $key => $a)
		{
			$array[$key]->date = date("d-m-Y", strtotime($a->date));
			$array[$key]->link = 'https://www.1001tracklists.com'.$a->link;
		}
return view("cracklist",["array"=>$array]);
}


public function newtrack(){

$check = topnewcomertrack::orderBy("id","desc")->first();
if($check)
{
//set the frequency. 24 means every 24 hours
	if(strtotime(date("Y-m-d",strtotime($check->created_at)+24*3600))<time()){

	if($html = file_get_html(url("newtracker"))){
		$array = topnewcomertrack::get();
		foreach($array as $a)
		{
			$topnewcomertrack = topnewcomertrack::find($a->id);
			$topnewcomertrack->delete();
		}
		foreach ($html->find(".ml2") as $key => $img) {
			$link = $img->find(".spr")?$img->find(".spr")[0]->href:"Undefined";
			$title = $img->find(".spr")?$img->find(".spr")[0]->innertext:"Undefined";
			$label = $img->find(".tracklabel")?$img->find(".tracklabel")[0]->innertext:"Undefined";
			$dj = $img->find(".playc")?$img->find(".playc")[0]->plaintext:"Undefined";
			// $dj = str_replace('<i class="fa fa-play-circle-o spr"></i>','',$dj);

			$topnewcomertrack = new topnewcomertrack;
			$topnewcomertrack->view = $link;
			$topnewcomertrack->title = $title;
			$topnewcomertrack->label =$label;
			$topnewcomertrack->dj = $dj;
			$topnewcomertrack->save(); 
		}
	}
	}
}else{
	if($html = file_get_html(url("newtracker"))){
		$array = topnewcomertrack::get();
		foreach($array as $a)
		{
			$topnewcomertrack = topnewcomertrack::find($a->id);
			$topnewcomertrack->delete();
		}
		foreach ($html->find(".ml2") as $key => $img) {

			$link = $img->find(".spr")?$img->find(".spr")[0]->href:"Undefined";
			$title = $img->find(".spr")?$img->find(".spr")[0]->innertext:"Undefined";
			$label = $img->find(".tracklabel")?$img->find(".tracklabel")[0]->innertext:"Undefined";
			$dj = $img->find(".playc")?$img->find(".playc")[0]->plaintext:"Undefined";
			// $dj = str_replace('<i class="fa fa-play-circle-o spr"></i>','',$dj);

			$topnewcomertrack = new topnewcomertrack;
			$topnewcomertrack->view = $link;
			$topnewcomertrack->title = $title;
			$topnewcomertrack->label =$label;
			$topnewcomertrack->dj = $dj;
			$topnewcomertrack->save(); 
		}
	}
}
		$array = topnewcomertrack::get();
		foreach($array as $key => $a)
		{
			$array[$key]->date = date("d-m-Y", strtotime($a->date));
			$array[$key]->link = 'https://www.1001tracklists.com'.$a->link;
		}
return view("newtrack",["array"=>$array]);
}

public function mostviewdetails(){
	$array = DB::select("SELECT *, COUNT(*) as countse FROM detailsloads GROUP BY `title` ORDER BY COUNT(*) DESC");
return view("mostdetails",["array"=>$array]);
}
}
