<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\mostview;
use App\Models\topnewcomertrack;
use App\Models\mostplayedtrack;
use App\Models\detailsload;
use App\Models\singletrack;
use DB;
use Auth;
include 'simple_html_dom.php';
class soft extends Controller
{
    public function __construct()
    {

    }
    public function detailsload()
    {
    	$time = time();

    	echo '<body id="body"><style> *{background:black; color: white; font: 25px arial;}</style>';
	echo '<script src="'.url("public/src/assets/js/vendor/jquery-3.3.1.min.js").'"></script><script>

	// If you don\'t know when data comes, you can set an interval:
window.setInterval(function() {
  $("body,html").animate({
  	scrollTop: 1000000
  	},1000);
}, 1000);



</script>';
	$files = mostview::get();
	if(!$files){
		return redirect('mostview');
	}


	$j = 0;
	echo "Scrapping from web...";
	for($i = 0; $i<count($files); $i++){
sleep(10); // Sleep for 10 or  you will be blocked
if($file = file_get_html("https://www.1001tracklists.com".$files[$i]->link))
{
	foreach ($file->find(".bItm") as $key=> $bt)
	{
		echo "Index: ".$j."<br>";
		$j++;
		$titlelabel = $bt->find(".fontL .notranslate")?$bt->find(".fontL .notranslate")[0]->plaintext:"Undefined";

		$dj = $bt->find(".bCont .mt5 .mr10")?$bt->find(".bCont .mt5 .mr10")[0]->plaintext:($bt->find(".bCont .noMob")?$bt->find(".bCont .noMob")[0]->plaintext:"Undefined");
		
		$tb = explode('-',$titlelabel);
		if (isset($tb[0])) {
			$title = $tb[0];
		}else{
			$title = "Undefined";
		}
		if (isset($tb[1])) {
			$label = $tb[1];
		}else{
			$title = "Undefined";
		}

		$detailsload = new detailsload;
		$detailsload->mid = $time;
		$detailsload->downloaded = detailsload::where("title","=",$titlelabel)->first()?detailsload::where("title","=",$titlelabel)->first()->downloaded:0;

		$detailsload->title = $titlelabel;
		$detailsload->label = '';
		$detailsload->dj = '';
		$detailsload->save();
		
	}

		$ft = detailsload::where("mid","!=",$time)->get();
	foreach($ft as $kes=> $f)
	{
		$eon = detailsload::find($f->id);
		$eon->delete();
		echo "Deleteding previous data: ".$kes." <br>";
	}
}

}

return redirect("mostviewdetails");
    }












public function clear()
{
	$dt  = singletrack::get();
	foreach($dt as $d)
	{
		$s  = singletrack::find($d->id);
		$s->delete();
	}
}

function urler(Request $request){
	$time = time();
if($file = file_get_html($request->get("url")))
{
	$i = 0;
	foreach ($file->find(".bItm") as $key=> $bt)
	{
		if($bt->find(".fontXL")){
		$i++;
			
		// echo '<div style="border: 1px solid red;">';
		// echo $i.$bt;
		$titlelabel = $bt->find(".trackValue")?$bt->find(".trackValue")[0]->plaintext:"Undefined";

		$dj = $bt->find('span[title="total tracklist plays"]')?$bt->find('span[title="total tracklist plays"]')[0]->plaintext:"Undefined";
		

		$singletrack = new singletrack;
		$singletrack->mid = $time;
		$singletrack->downloaded = detailsload::where("title","=",$titlelabel)->first()?detailsload::where("title","=",$titlelabel)->first()->downloaded:0;

		$singletrack->title = $titlelabel;
		$singletrack->label = '';
		$singletrack->dj = $dj;
		$singletrack->save();
		// echo '</div>';
		}
		
}
}




}





















    public function trackcrack()
    {

    		for($i = 1; $i<11; $i++){

if($file = file_get_html("https://www.1001tracklists.com/ajax/getmostviewedtls.php?mode=1&id=2&param=nc7&showRank=true&page=$i"))
{
	$file = json_decode($file, true);
	print_r($file['data']);
}
sleep(10);	// Sleeps 10 seconds

}
}


public function mostplay()
{
	for($i = 1; $i<11; $i++){

if($file = file_get_html("https://www.1001tracklists.com/ajax/getmostplayedtracks.php?mode=2&id=2&param=4w&showRank=true&page=$i"))
{
	$file = json_decode($file, true);
	print_r($file['data']);
}
sleep(10);	// Sleeps 10 seconds

}
    }

public function newtracker()
{
	for($i = 1; $i<6; $i++){

if($file = file_get_html("https://www.1001tracklists.com/ajax/getmostplayedtracks.php?mode=2&id=2&param=nc&showRank=true&page=$i"))
{
	$file = json_decode($file, true);
	print_r($file['data']);
}
sleep(10);	// Sleeps 10 seconds

}
}



public function tracklist(Request $request)
{

	$check = mostview::orderBy("id","desc")->first();
if($check && $request->get("do"))
{
//set the frequency. 24 means every 24 hours
	if(strtotime(date("Y-m-d",strtotime($check->created_at)+24*3600))<time()){

	if($html = file_get_html(url("trackcrack"))){
		$array = mostview::get();
		foreach($array as $a)
		{
			$mostview = mostview::find($a->id);
			$mostview->delete();
		}
		foreach ($html->find(".ml5") as $key => $img) {
			$link = $img->find("a")[0]->href;
			$title = $img->find("a")[0]->innertext;
			$view = $img->find(".tlviews")[0]->innertext;
			$view = str_replace('<i class="fa fa-eye spr"></i>','',$view);
			$date = $img->find("span[title=tracklist date]")[0]->innertext;

			$mostview = new mostview;
			$mostview->link = $link;
			$mostview->title = $title;
			$mostview->view =$view;
			$mostview->date = $date;
			$mostview->save(); 
		}
		return "Scrapped";
	}
	}
}else{
	if($request->get("do") && $html = file_get_html(url("trackcrack"))){
		$array = mostview::get();
		foreach($array as $a)
		{
			$mostview = mostview::find($a->id);
			$mostview->delete();
		}
		foreach ($html->find(".ml5") as $key => $img) {
			$link = $img->find("a")[0]->href;
			$title = $img->find("a")[0]->innertext;
			$view = $img->find(".tlviews")[0]->innertext;
			$view = str_replace('<i class="fa fa-eye spr"></i>','',$view);
			$date = $img->find("span[title=tracklist date]")[0]->innertext;

			$mostview = new mostview;
			$mostview->link = $link;
			$mostview->title = $title;
			$mostview->view =$view;
			$mostview->date = $date;
			$mostview->save(); 
			

		}
				return "Scrapped";

	}
}
if($request->get("do")){
	return "";
}
		$array = mostview::get();
		foreach($array as $key => $a)
		{
			$array[$key]->date = date("d-m-Y", strtotime($a->date));
			$array[$key]->link = 'https://www.1001tracklists.com'.$a->link;
		}

				if(!$check || strtotime(date("Y-m-d",strtotime($check->created_at)+24*3600))<time()){
return view("tracklist",["array"=>[]]);
		}else{
return view("tracklist",["array"=>$array]);
}
}

public function mostplayed(Request $request)
{
$time = time();
$check = mostplayedtrack::orderBy("id","desc")->first();
if($check && $request->get("do"))
{
//set the frequency. 24 means every 24 hours
	if(strtotime(date("Y-m-d",strtotime($check->created_at)+24*3600))<time()){

	if($html = file_get_html(url("mostplay"))){

		foreach ($html->find(".ml2") as $key => $img) {
			$link = $img->find(".spr")?$img->find(".spr")[0]->href:"Undefined";
			$title = $img->find(".spr")?$img->find(".spr")[0]->innertext:"Undefined";
			$label = $img->find(".tracklabel")?$img->find(".tracklabel")[0]->innertext:"Undefined";
			$dj = $img->find(".playc")?$img->find(".playc")[0]->plaintext:"Undefined";
			// $dj = str_replace('<i class="fa fa-play-circle-o spr"></i>','',$dj);

			$mostplayedtrack = new mostplayedtrack;
			$mostplayedtrack->downloaded = mostplayedtrack::where("title","=",$title)->first()?mostplayedtrack::where("title","=",$title)->first()->downloaded:0;
			$mostplayedtrack->mid = $time;
			$mostplayedtrack->view = $link;
			$mostplayedtrack->title = $title;
			$mostplayedtrack->label =$label;
			$mostplayedtrack->dj = $dj;
			$mostplayedtrack->save(); 
		}
				$array = mostplayedtrack::where("mid","!=",$time)->get();
		foreach($array as $a)
		{
			$mostplayedtrack = mostplayedtrack::find($a->id);
			$mostplayedtrack->delete();
		}
		return "Scrapped";
	}
	}
}else{
	if($request->get("do") && $html = file_get_html(url("mostplay"))){

		foreach ($html->find(".ml2") as $key => $img) {

			$link = $img->find(".spr")?$img->find(".spr")[0]->href:"Undefined";
			$title = $img->find(".spr")?$img->find(".spr")[0]->innertext:"Undefined";
			$label = $img->find(".tracklabel")?$img->find(".tracklabel")[0]->innertext:"Undefined";
			$dj = $img->find(".playc")?$img->find(".playc")[0]->plaintext:"Undefined";
			// $dj = str_replace('<i class="fa fa-play-circle-o spr"></i>','',$dj);

			$mostplayedtrack = new mostplayedtrack;
			$mostplayedtrack->downloaded = mostplayedtrack::where("title","=",$title)->first()?mostplayedtrack::where("title","=",$title)->first()->downloaded:0;
			$mostplayedtrack->mid = $time;
			$mostplayedtrack->view = $link;
			$mostplayedtrack->title = $title;
			$mostplayedtrack->label =$label;
			$mostplayedtrack->dj = $dj;
			$mostplayedtrack->save(); 
		}

				$array = mostplayedtrack::where("mid","!=",$time)->get();
		foreach($array as $a)
		{
			$mostplayedtrack = mostplayedtrack::find($a->id);
			$mostplayedtrack->delete();
		}
				return "Scrapped";

	}
}
if ($request->get("do")) {
	return "";
}
		$array = mostplayedtrack::get();
		foreach($array as $key => $a)
		{
			$array[$key]->date = date("d-m-Y", strtotime($a->date));
			$array[$key]->link = 'https://www.1001tracklists.com'.$a->link;
		}

		if(!$check || strtotime(date("Y-m-d",strtotime($check->created_at)+24*3600))<time()){
return view("cracklist",["array"=>[]]);
		}else{
return view("cracklist",["array"=>$array]);
		}
}


public function newtrack(Request $request){
$time = time();
$check = topnewcomertrack::orderBy("id","desc")->first();
if($check && $request->get("do"))
{
//set the frequency. 24 means every 24 hours
	if(strtotime(date("Y-m-d",strtotime($check->created_at)+24*3600))<time()){

	if($html = file_get_html(url("newtracker"))){
		$array = topnewcomertrack::get();

		foreach ($html->find(".ml2") as $key => $img) {
			$link = $img->find(".spr")?$img->find(".spr")[0]->href:"Undefined";
			$title = $img->find(".spr")?$img->find(".spr")[0]->innertext:"Undefined";
			$label = $img->find(".tracklabel")?$img->find(".tracklabel")[0]->innertext:"Undefined";
			$dj = $img->find(".playc")?$img->find(".playc")[0]->plaintext:"Undefined";
			// $dj = str_replace('<i class="fa fa-play-circle-o spr"></i>','',$dj);

			$topnewcomertrack = new topnewcomertrack;
			$topnewcomertrack->view = $link;
			$topnewcomertrack->downloaded = topnewcomertrack::where("title","=",$title)->first()?topnewcomertrack::where("title","=",$title)->first()->downloaded:0;

			$topnewcomertrack->mid = $time;
			$topnewcomertrack->title = $title;
			$topnewcomertrack->label =$label;
			$topnewcomertrack->dj = $dj;
			$topnewcomertrack->save(); 
		}
				$array = topnewcomertrack::where("mid","!=",$time)->get();
		foreach($array as $a)
		{
			$topnewcomertrack = topnewcomertrack::find($a->id);
			$topnewcomertrack->delete();
		}
	}
	return "Scrapped";
	}
}else{
	if($request->get("do") && $html = file_get_html(url("newtracker"))){

		foreach ($html->find(".ml2") as $key => $img) {

			$link = $img->find(".spr")?$img->find(".spr")[0]->href:"Undefined";
			$title = $img->find(".spr")?$img->find(".spr")[0]->innertext:"Undefined";
			$label = $img->find(".tracklabel")?$img->find(".tracklabel")[0]->innertext:"Undefined";
			$dj = $img->find(".playc")?$img->find(".playc")[0]->plaintext:"Undefined";
			// $dj = str_replace('<i class="fa fa-play-circle-o spr"></i>','',$dj);

			$topnewcomertrack = new topnewcomertrack;
			$topnewcomertrack->view = $link;
			$topnewcomertrack->mid = $time;

			$topnewcomertrack->downloaded = topnewcomertrack::where("title","=",$title)->first()?topnewcomertrack::where("title","=",$title)->first()->downloaded:0;

			$topnewcomertrack->title = $title;
			$topnewcomertrack->label =$label;
			$topnewcomertrack->dj = $dj;
			$topnewcomertrack->save(); 
		}
				$array = topnewcomertrack::where("mid","!=",$time)->get();
		foreach($array as $a)
		{
			$topnewcomertrack = topnewcomertrack::find($a->id);
			$topnewcomertrack->delete();
		}
		return "Scrapped";
	}

}

if ($request->get("do")) {
	return "";
}
		$array = topnewcomertrack::get();
		foreach($array as $key => $a)
		{
			$array[$key]->date = date("d-m-Y", strtotime($a->date));
			$array[$key]->link = 'https://www.1001tracklists.com'.$a->link;
		}
				if(!$check || strtotime(date("Y-m-d",strtotime($check->created_at)+24*3600))<time()){
return view("topnewcomer",["array"=>[]]);
		}else{
return view("topnewcomer",["array"=>$array]);
}
}

public function mostviewdetails(){
	$array = DB::select("SELECT *, COUNT(*) as countse FROM detailsloads GROUP BY `title` ORDER BY COUNT(*) DESC");
return view("mostviewedtracks-detailed",["array"=>$array]);
}

public function singletrack(){
	$array = DB::select("SELECT *, COUNT(*) as countse FROM singletracks GROUP BY `title` ORDER BY COUNT(*) DESC");
	return view("singletrack",["array"=>$array]);
}

public function updatemostplayedlist(Request $request)
{
	$mostplayed = mostplayedtrack::find($request->get("id"));
	$title = $mostplayed->title;
	$a1 = mostplayedtrack::where("title","=",$title)->get();
	foreach($a1 as $a)
	{
		$a11 = mostplayedtrack::find($a->id);
		if ($a11->downloaded==1) {
			$a11->downloaded=0;
		}else{
			$a11->downloaded=1;
		}
		$a11->save();
	}
	$a2 = topnewcomertrack::where("title","=",$title)->get();
	foreach($a2 as $a)
	{
		$a11 = topnewcomertrack::find($a->id);
		if ($a11->downloaded==1) {
			$a11->downloaded=0;
		}else{
			$a11->downloaded=1;
		}
		$a11->save();
	}

	$a3 = detailsload::where("title","=",$title)->get();
	foreach($a3 as $a)
	{
		$a11 = detailsload::find($a->id);
		if ($a11->downloaded==1) {
			$a11->downloaded=0;
		}else{
			$a11->downloaded=1;
		}
		$a11->save();
	}
	
	return __("Updated");
}
public function updatenewtrack(Request $request)
{
	$mostplayed = topnewcomertrack::find($request->get("id"));
	$title = $mostplayed->title;
	$a1 = mostplayedtrack::where("title","=",$title)->get();
	foreach($a1 as $a)
	{
		$a11 = mostplayedtrack::find($a->id);
		if ($a11->downloaded==1) {
			$a11->downloaded=0;
		}else{
			$a11->downloaded=1;
		}
		$a11->save();
	}
	$a2 = topnewcomertrack::where("title","=",$title)->get();
	foreach($a2 as $a)
	{
		$a11 = topnewcomertrack::find($a->id);
		if ($a11->downloaded==1) {
			$a11->downloaded=0;
		}else{
			$a11->downloaded=1;
		}
		$a11->save();
	}

	$a3 = detailsload::where("title","=",$title)->get();
	foreach($a3 as $a)
	{
		$a11 = detailsload::find($a->id);
		if ($a11->downloaded==1) {
			$a11->downloaded=0;
		}else{
			$a11->downloaded=1;
		}
		$a11->save();
	}
	
	return __("Updated");
}
public function updatedetails(Request $request)
{
	$mostplayed = detailsload::find($request->get("id"));
	$title = $mostplayed->title;
	$a1 = mostplayedtrack::where("title","=",$title)->get();
	foreach($a1 as $a)
	{
		$a11 = mostplayedtrack::find($a->id);
		if ($a11->downloaded==1) {
			$a11->downloaded=0;
		}else{
			$a11->downloaded=1;
		}
		$a11->save();
	}
	$a2 = topnewcomertrack::where("title","=",$title)->get();
	foreach($a2 as $a)
	{
		$a11 = topnewcomertrack::find($a->id);
		if ($a11->downloaded==1) {
			$a11->downloaded=0;
		}else{
			$a11->downloaded=1;
		}
		$a11->save();
	}

	$a3 = detailsload::where("title","=",$title)->get();
	foreach($a3 as $a)
	{
		$a11 = detailsload::find($a->id);
		if ($a11->downloaded==1) {
			$a11->downloaded=0;
		}else{
			$a11->downloaded=1;
		}
		$a11->save();
	}
	
	return __("Updated");
}
}
