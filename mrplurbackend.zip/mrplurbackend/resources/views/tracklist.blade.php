@extends("layout.app")
@section("title",__("Tracklist - mrplurssive admin panel"))
@section("page")
<a href="{{url('tracklist')}}" class="btn btn-info m-1" style="color: white;">Most Viewed</a>
<a href="{{url('mostplayed')}}" class="btn btn-secondary m-1">Most Played</a>
<a href="{{url('newtrack')}}" class="btn btn-secondary m-1">New tracks</a>
<a href="{{url('mostviewdetails')}}" class="btn btn-secondary m-1">Most View Tracks Details</a>

<br>
@endsection
@section("content")

<table class="table custom">
	<tr>
		<th>#</th>
		<th>Title</th>
		<th>Views</th>
		<th>Link</th>
		<th>Date</th>
	</tr>
	@foreach ($array as $key=>$el)
		<tr>
			<td>{{$key+1}}</td>
			<td>{{str_replace(array("&amp;","&euml;","&eacute;"),array("&","e","e"),$el->title)}}</td>
			<td>{{$el->view}}</td>
			<td><a href="{{$el->link}}" target="_blank" style="color: lightblue;">{{$el->link}}</a></td>
			<td>{{$el->date}}</td>
		</tr>
	@endforeach
</table>

@endsection