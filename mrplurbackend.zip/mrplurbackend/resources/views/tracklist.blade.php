@extends("layout.app")
@section("title",__("Tracklist - mrplurssive admin panel"))
@section("page")
<a href="{{url('tracklist')}}" class="btn btn-info m-1" style="color: white;">Most Viewed Tracklist</a>
<a href="{{url('mostplayed')}}" class="btn btn-secondary m-1">Most Played Tracks</a>
<a href="{{url('topnewcomertracks')}}" class="btn btn-secondary m-1">Top Newcomer Tracks</a>
<a href="{{url('mostviewedtracks-detailed')}}" class="btn btn-secondary m-1">Most Viewed Tracks (Detailed)</a>
<a href="{{url('scrap-single-track')}}" class="btn btn-secondary m-1">Scrap Single Track</a>

<br>
@endsection
@section("content")
<div class="pt"></div>
@foreach ($array as $key=>$el)
@php
	$tm = strtotime($el->created_at);
	date_default_timezone_set("Asia/Singapore");
@endphp
<div class="alert alert-success float-right">Scrapped on:
{{date("d M Y, h:i a", $tm)}}
</div>
@break
@endforeach
<table class="table custom">
	<tr>
		<th>#</th>
		<th>Title</th>
		<th>Views</th>
		<th>Link</th>
		<th>Date</th>
	</tr>
	@foreach ($array as $key=>$el)
		<tr>
			<td>{{$key+1}}</td>
			<td>{{str_replace(array("&amp;","&euml;","&eacute;","&Oslash;","&oslash;","&nbsp;"),array("&","e","e","O","o",""),$el->title)}}</td>
			<td>{{$el->view}}</td>
			<td><a href="{{$el->link}}" target="_blank" style="color: lightblue;">{{$el->link}}</a></td>
			<td>{{$el->date}}</td>
		</tr>
	@endforeach
</table>
<script>
	function a() {
		$.ajax({
			url: '{{ url('/tracklist') }}',
			type: 'GET',
			data: {do: 'do', _token:"{{csrf_token()}}"},
			beforeSend:function(){
				$(".pt").html('<div class="alert alert-danger">Scrapping... <br> Please wait a minute. Don\'t leave this page while scrapping.</div>');
			}
		})
		.done(function(data) {
			if($.trim(data)!='')
			{
				$(".pt").html('<div class="alert alert-success">Updated Data.</div>');
				location.reload();
			}else{
				$(".pt").html('');
			}
		});
	}
</script>
@endsection