@extends("layout.app")
@section("title",__("Tracklist - mrplurssive admin panel"))
@section("page")
<a href="{{url('top-overall-tracks')}}" class="btn btn-secondary m-1">Top Overall Tracks</a>
<a href="{{url('mostplayed')}}" class="btn btn-secondary m-1">Most Played Tracks</a>
<a href="{{url('topnewcomertracks')}}" class="btn btn-info m-1" style="color: white;">Top Newcomer Tracks</a>
<a href="{{url('mostviewedtracks-detailed')}}" class="btn btn-secondary m-1">Most Viewed Tracks (Detailed)</a>
<a href="{{url('scrap-single-track')}}" class="btn btn-secondary m-1">Scrap Single Track</a>

<br>
@endsection
@section("content")
<div class="pt"></div>
@foreach ($array as $key=>$el)
@php
	$tm = strtotime($el->created_at);
	date_default_timezone_set("Asia/Singapore");
@endphp
<div class="alert alert-success float-right">Scrapped on:
{{date("d M Y, h:i a", $tm)}}
</div>
@break
@endforeach
<table class="table custom">
	<tr>
		<th>#</th>
		<th>Downloaded</th>
		<th>Title</th>
		<th>DJ support</th>
		<th>Label</th>
		<th>VK Search</th>
		<th>Drive Search</th>

		<th>Spotify Search</th>
	</tr>
	@foreach ($array as $key=>$el)
		<tr>
			<td>{{$key+1}}</td>
			<td>
				@if($el->downloaded==1)
				<input type="checkbox" checked="checked" onchange="al({{$el->id}})">
				@else
				<input type="checkbox" onchange="al({{$el->id}})">
				@endif
			</td>
			<td>{{str_replace(array("&amp;","&euml;","&eacute;","&Oslash;","&oslash;","&nbsp;"),array("&","e","e","O","o",""),$el->title)}}</td>
			<td>{{$el->dj}}</td>
			<td>{{$el->label}}</td>
			{{-- <td><a href="{{$el->link}}" target="_blank" style="color: lightblue;">{{$el->link}}</a></td> --}}
			<td><a href="https://vk.com/search?c[per_page]=200&c[q]={{urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))}}&c[section]=audio" class="btn btn-secondary" target="_blank">VK Search</a></td>
			<td><a href="https://drive.google.com/drive/u/0/search?q={{urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))}}" class="btn btn-secondary" target="_blank">Drive Search</a></td>
			
			<td><a href="https://open.spotify.com/search/{{$el->title}}" class="btn btn-secondary" target="_blank">Spotify Search</a></td>


			{{-- <td><a href="https://vk.com/search?c[per_page]=200&c[q]={{urlencode($el->title)}}&c[section]=audio" class="btn btn-secondary" target="_blank">Search</a></td> --}}

 		</tr>
	@endforeach
</table>
<script>
	function al(id)
	{
		$.ajax({
			url: '{{url("/updatenewtrack")}}',
			type: "POST",
			data: {id:id, _token: "{{csrf_token()}}"},
			success:function(data){
				console.log(data);
			}
		});
	}

	function a() {
		$.ajax({
			url: '{{ url('/topnewcomertracks') }}',
			type: 'GET',
			data: {do: 'do', _token:"{{csrf_token()}}"},
			beforeSend:function(){
				$(".pt").html('<div class="alert alert-danger">Scrapping... <br> Please wait a minute. Don\'t leave this page while scrapping.</div>');
			}
		})
		.done(function(data) {
			if($.trim(data)!='')
			{
				$(".pt").html('<div class="alert alert-success">Updated Data.</div>');
				location.reload();
			}else{
				$(".pt").html('');
			}
		});
	}
</script>
@endsection