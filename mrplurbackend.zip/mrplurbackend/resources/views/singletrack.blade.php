@extends("layout.app")
@section("title",__("Tracklist - mrplurssive admin panel"))
@section("page")
<a href="{{url('tracklist')}}" class="btn btn-secondary m-1">Most Viewed Tracklist</a>
<a href="{{url('mostplayed')}}" class="btn btn-secondary m-1">Most Played Tracks</a>
<a href="{{url('topnewcomertracks')}}" class="btn btn-secondary m-1">Top Newcomer Tracks</a>
<a href="{{url('mostviewedtracks-detailed')}}" class="btn btn-secondary m-1">Most Viewed Tracks (Detailed)</a>
<a href="{{url('scrap-single-track')}}" class="btn btn-info m-1" style="color: white;">Scrap Single Track</a>

<br>
@endsection
@section("content")
<div class="pt"></div>
@foreach ($array as $key=>$el)
@php
	$tm = strtotime($el->created_at);
	date_default_timezone_set("Asia/Singapore");
@endphp
<div class="alert alert-success float-right">Scrapped on:
{{date("d M Y, h:i a", $tm)}}
</div>
@break
@endforeach
<div class="row">
<div class="col-8">
<input type="text" id="so" placeholder="URL" class="form-control">
</div>
<div class="col-4">
<button class="btn btn-primary" style="color: white" onclick="fetch(this)">Fetch</button>
<button class="btn btn-danger" style="color: white" onclick="clears(this)">Clear</button>
</div>
</div>
<table class="table custom">
	<tr>
		<th>#</th>
		<th>Downloaded</th>
		<th>Title</th>
		<th>DJ support</th>
		<th>VK Search</th>
		<th>Drive Search</th>
		<th>Spotify Search</th>
	</tr>
	@foreach ($array as $key=>$el)
	@php
		if ($el->title==' ID  -  ID   ' || $el->title=='') {
			continue;
		}
	@endphp
		<tr>
			<td>{{$key+1}}</td>
			<td>
				@if($el->downloaded==1)
				<input type="checkbox" checked="checked" onchange="al({{$el->id}})">
				@else
				<input type="checkbox" onchange="al({{$el->id}})">
				@endif
			</td>
			<td>{{str_replace(array("&amp;","&euml;","&eacute;","&Oslash;","&oslash;","&nbsp;"),array("&","e","e","O","o",""),$el->title)}}</td>
			<td>{{$el->dj}}</td>
			{{-- <td><a href="{{$el->link}}" target="_blank" style="color: lightblue;">{{$el->link}}</a></td> --}}
			<td><a href="https://vk.com/search?c[per_page]=200&c[q]={{urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))}}&c[section]=audio" class="btn btn-secondary" target="_blank">VK Search</a></td>
			<td><a href="https://drive.google.com/drive/u/0/search?q={{urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))}}" class="btn btn-secondary" target="_blank">Drive Search</a></td>
			
			<td><a href="https://open.spotify.com/search/{{$el->title}}" class="btn btn-secondary" target="_blank">Spotify Search</a></td>


			{{-- <td><a href="https://vk.com/search?c[per_page]=200&c[q]={{urlencode($el->title)}}&c[section]=audio" class="btn btn-secondary" target="_blank">Search</a></td> --}}

 		</tr>
	@endforeach
</table>
<script>
	function al(id)
	{
		$.ajax({
			url: '{{url("/updatenewtrack")}}',
			type: "POST",
			data: {id:id, _token: "{{csrf_token()}}"},
			success:function(data){
				console.log(data);
			}
		});
	}

	function fetch(t){
		if($.trim($("#so").val())==''){
			alert("No url Found");
		}else{
			$.ajax({
			url: '{{url("/urler")}}',
			type: "GET",
			data: {url:$("#so").val(), _token: "{{csrf_token()}}"},
			beforeSend:function()
			{
				$(t).html("Processing");
			},
			success:function(data){
				console.log(data);
				$(t).html("Reloading");
				location.reload();
			}
		});
		}
	}



	function clears(t)
	{
		$.ajax({
			url: '{{url("/clear")}}',
			type: "GET",
			data: { _token: "{{csrf_token()}}"},
			beforeSend:function()
			{
				$(t).html("Processing");
			},
			success:function(data){
				console.log(data);
				$(t).html("Reloading");
				location.reload();
			}
		});
	}

</script>
@endsection