@extends("layout.app")
@section("title",__("Most Views Details - mrplurssive admin panel"))
@section("page")
<a href="{{url('top-overall-tracks')}}" class="btn btn-secondary m-1">Top Overall Tracks</a>
<a href="{{url('mostplayed')}}" class="btn btn-secondary m-1">Most Played Tracks</a>
<a href="{{url('topnewcomertracks')}}" class="btn btn-secondary m-1">Top Newcomer Tracks</a>
<a href="{{url('mostviewedtracks-detailed')}}" class="btn btn-info m-1" style="color: white;">Most Viewed Tracks (Detailed)</a>
<a href="{{url('scrap-single-track')}}" class="btn btn-secondary m-1">Scrap Single Track</a>

<br>
@endsection
@section("content")
<a href="{{url('detailsload')}}" class="btn btn-red" style="color: white;" onclick="loading()">Clear & Reload Data</a>
<script>
	function loading()
	{
		$(".loading").show();
	}
</script>
<div class="loading alert alert-danger" style="display: none">Scrapping...</div>
@foreach ($array as $key=>$el)
@php
	$tm = strtotime($el->created_at);
	date_default_timezone_set("Asia/Singapore");
@endphp
<div class="alert alert-success float-right">Scrapped on:
{{date("d M Y, h:i a", $tm)}}
</div>
@break
@endforeach
<table class="table custom">
	<tr>
		<th>#</th>
		<th>Downloaded</th>
		<th>Title</th>
		<th>Count</th>
		<th>VK search</th>
				<th>Drive Search</th>

		<th>Spotify search</th>
	</tr>
	@foreach ($array as $key=>$el)
	@php
		if ($el->title==' ID  -  ID   ' || $el->title=='') {
			continue;
		}
	@endphp
		<tr>
			<td>{{$key+1}}</td>
			<td>
				@if($el->downloaded==1)
				<input type="checkbox" checked="checked" onchange="al({{$el->id}})">
				@else
				<input type="checkbox" onchange="al({{$el->id}})">
				@endif
			</td>
			<td>{{trim(preg_replace('/\s+/'," ",(str_replace(array("&amp;","&euml;","&eacute;","&Oslash;","&oslash;","&nbsp;"),array("&","e","e","O","o",""),$el->title))))}}</td>
			<td>{{$el->countse}}</td>
			<td><a href="https://vk.com/search?c[per_page]=200&c[q]={{urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))}}&c[section]=audio" class="btn btn-secondary" target="_blank">VK Search</a></td>
			<td><a href="https://drive.google.com/drive/u/0/search?q={{urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))}}" class="btn btn-secondary" target="_blank">Drive Search</a></td>

			<td><a href="https://open.spotify.com/search/{{$el->title}}" class="btn btn-secondary" target="_blank">Spotify Search</a></td>
			{{-- <td>{{$el->label}}</td> --}}
			{{-- <td><a href="{{$el->link}}" target="_blank" style="color: lightblue;">{{$el->link}}</a></td> --}}
			{{-- <td><a href="https://vk.com/search?c[per_page]=200&c[q]={{urlencode(str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;'), array('','','','','','','','','',' '),$el->title))}}&c[section]=audio" class="btn btn-secondary" target="_blank">Search</a></td> --}}

			{{-- <td><a href="https://vk.com/search?c[per_page]=200&c[q]={{urlencode($el->title)}}&c[section]=audio" class="btn btn-secondary" target="_blank">Search</a></td> --}}

 		</tr>
	@endforeach
</table>
<script>
	function al(id)
	{
		$.ajax({
			url: '{{url("/updatedetails")}}',
			type: "POST",
			data: {id:id, _token: "{{csrf_token()}}"},
			success:function(data){
				console.log(data);
			}
		});
	}



</script>
@endsection