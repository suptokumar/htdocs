@extends("layout.app")
@section("title",__("Tracklist - mrplurssive admin panel"))
@section("page")
<div class="breadcrumb">
<a href="{{url('tracklist')}}" class="btn btn-secondary m-1">Most Viewed</a>
<a href="{{url('mostplayed')}}" class="btn btn-info m-1" style="color: white;">Most Played Tracks</a>
<a href="{{url('newtrack')}}" class="btn btn-secondary m-1">Top Newcomer Tracks</a>
<a href="{{url('mostviewdetails')}}" class="btn btn-secondary m-1">Most Viewed Tracks (Detailed)</a>

<br>
</div>
@endsection
@section("content")
<table class="table custom">
	<tr>
		<th>#</th>
		<th>Title</th>
		<th>DJ support</th>
		<th>Label</th>
		<th>VK Search</th>
		<th>Spotify Search</th>
	</tr>
	@foreach ($array as $key=>$el)
		<tr>
			<td>{{$key+1}}</td>
			<td>{{str_replace(array("&amp;","&euml;","&eacute;"),array("&","e","e"),$el->title)}}</td>
			<td>{{$el->dj}}</td>
			<td>{{$el->label}}</td>
			{{-- <td><a href="{{$el->link}}" target="_blank" style="color: lightblue;">{{$el->link}}</a></td> --}}

			<td><a href="https://vk.com/search?c[per_page]=200&c[q]={{urlencode(str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;'), array('','','','','','','','','',' '),$el->title))}}&c[section]=audio" class="btn btn-secondary" target="_blank">VK Search</a></td>
			<td><a href="https://open.spotify.com/search/{{urlencode(str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;'), array('','','','','','','','','',' '),$el->title))}}" class="btn btn-secondary" target="_blank">Spotify Search</a></td>

			{{-- <td><a href="https://vk.com/search?c[per_page]=200&c[q]={{urlencode($el->title)}}&c[section]=audio" class="btn btn-secondary" target="_blank">Search</a></td> --}}
		</tr>
	@endforeach
</table>

@endsection