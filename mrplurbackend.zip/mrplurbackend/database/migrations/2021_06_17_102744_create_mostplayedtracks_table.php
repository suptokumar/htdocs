<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMostplayedtracksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mostplayedtracks', function (Blueprint $table) {
            $table->id();
            $table->text("downloaded");
            $table->text("mid");
            $table->text("view");
            $table->text("title");
            $table->text("dj");
            $table->text("label");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mostplayedtracks');
    }
}
