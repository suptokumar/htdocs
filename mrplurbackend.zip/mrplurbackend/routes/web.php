<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
    return redirect('top-overall-tracks');
});

Route::get('/youtube', function () {
    return view('welcome');
});


Route::get("/detailsload", 'soft@detailsload');



Route::get("/trackcrack", 'soft@trackcrack');

Route::get("/mostplay", 'soft@mostplay');
Route::get("/newtracker", 'soft@newtracker');
Route::get('/top-overall-tracks', 'soft@tracklist');





Route::get('/mostplayed', 'soft@mostplayed');



Route::get('/topnewcomertracks', 'soft@newtrack');
Route::get('/scrap-single-track', 'soft@singletrack');
Route::get('/urler', 'soft@urler');
Route::get('/clear', 'soft@clear');

Route::get("mostviewedtracks-detailed",'soft@mostviewdetails');
Route::post("updatedetails",'soft@updatedetails');
Route::post("updatenewtrack",'soft@updatenewtrack');
Route::post("updatemostplayedlist",'soft@updatemostplayedlist');
		