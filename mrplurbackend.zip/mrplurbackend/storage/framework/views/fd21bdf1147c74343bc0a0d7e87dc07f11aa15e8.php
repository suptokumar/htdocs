
<?php $__env->startSection("title",__("Tracklist - mrplurssive admin panel")); ?>
<?php $__env->startSection("page"); ?>
<a href="<?php echo e(url('tracklist')); ?>" class="btn btn-info m-1" style="color: white;">Most Viewed</a>
<a href="<?php echo e(url('mostplayed')); ?>" class="btn btn-secondary m-1">Most Played</a>
<a href="<?php echo e(url('newtrack')); ?>" class="btn btn-secondary m-1">New tracks</a>
<a href="<?php echo e(url('mostviewdetails')); ?>" class="btn btn-secondary m-1">Most View Tracks Details</a>

<br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>

<table class="table custom">
	<tr>
		<th>#</th>
		<th>Title</th>
		<th>Views</th>
		<th>Link</th>
		<th>Date</th>
	</tr>
	<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($key+1); ?></td>
			<td><?php echo e(str_replace(array("&amp;","&euml;","&eacute;"),array("&","e","e"),$el->title)); ?></td>
			<td><?php echo e($el->view); ?></td>
			<td><a href="<?php echo e($el->link); ?>" target="_blank" style="color: lightblue;"><?php echo e($el->link); ?></a></td>
			<td><?php echo e($el->date); ?></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mrplurbackend\resources\views/tracklist.blade.php ENDPATH**/ ?>