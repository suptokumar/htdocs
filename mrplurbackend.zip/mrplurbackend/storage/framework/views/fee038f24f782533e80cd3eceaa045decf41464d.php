
<?php $__env->startSection("title",__("Tracklist - mrplurssive admin panel")); ?>
<?php $__env->startSection("page"); ?>
<a href="<?php echo e(url('tracklist')); ?>" class="btn btn-secondary m-1">Most Viewed</a>
<a href="<?php echo e(url('mostplayed')); ?>" class="btn btn-secondary m-1">Most Played</a>
<a href="<?php echo e(url('newtrack')); ?>" class="btn btn-info m-1" style="color: white;">New tracks</a>
<a href="<?php echo e(url('mostviewdetails')); ?>" class="btn btn-secondary m-1">Most View Tracks Details</a>

<br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>

<table class="table custom">
	<tr>
		<th>#</th>
		<th>Title</th>
		<th>DJ support</th>
		<th>Label</th>
		<th>Search</th>
	</tr>
	<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($key+1); ?></td>
			<td><?php echo e(str_replace(array("&amp;","&euml;","&eacute;"),array("&","e","e"),$el->title)); ?></td>
			<td><?php echo e($el->dj); ?></td>
			<td><?php echo e($el->label); ?></td>
			
			<td><a href="https://vk.com/search?c[per_page]=200&c[q]=<?php echo e(urlencode(str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;'), array('','','','','','','','','',' '),$el->title))); ?>&c[section]=audio" class="btn btn-secondary" target="_blank">Search</a></td>

			

 		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mrplurssive\resources\views/newtrack.blade.php ENDPATH**/ ?>