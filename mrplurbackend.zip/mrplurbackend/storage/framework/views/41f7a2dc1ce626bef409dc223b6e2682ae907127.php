
<?php $__env->startSection("title",__("Tracklist - mrplurssive admin panel")); ?>
<?php $__env->startSection("page"); ?>
<a href="<?php echo e(url('top-overall-tracks')); ?>" class="btn btn-info m-1" style="color: white;">Top Overall Tracks</a>
<a href="<?php echo e(url('mostplayed')); ?>" class="btn btn-secondary m-1">Most Played Tracks</a>
<a href="<?php echo e(url('topnewcomertracks')); ?>" class="btn btn-secondary m-1">Top Newcomer Tracks</a>
<a href="<?php echo e(url('mostviewedtracks-detailed')); ?>" class="btn btn-secondary m-1">Most Viewed Tracks (Detailed)</a>
<a href="<?php echo e(url('scrap-single-track')); ?>" class="btn btn-secondary m-1">Scrap Single Track</a>

<br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="pt"></div>
<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
	$tm = strtotime($el->created_at);
	date_default_timezone_set("Asia/Singapore");
?>
<div class="alert alert-success float-right">Scrapped on:
<?php echo e(date("d M Y, h:i a", $tm)); ?>

</div>
<?php break; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<table class="table custom">
	<tr>
		<th>#</th>
		<th>Title</th>
		<th>Views</th>
		<th>Link</th>
		<th>Date</th>
	</tr>
	<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($key+1); ?></td>
			<td><?php echo e(str_replace(array("&amp;","&euml;","&eacute;","&Oslash;","&oslash;","&nbsp;"),array("&","e","e","O","o",""),$el->title)); ?></td>
			<td><?php echo e($el->view); ?></td>
			<td><a href="<?php echo e($el->link); ?>" target="_blank" style="color: lightblue;"><?php echo e($el->link); ?></a></td>
			<td><?php echo e($el->date); ?></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<script>
	function a() {
		$.ajax({
			url: '<?php echo e(url('/top-overall-tracks')); ?>',
			type: 'GET',
			data: {do: 'do', _token:"<?php echo e(csrf_token()); ?>"},
			beforeSend:function(){
				$(".pt").html('<div class="alert alert-danger">Scrapping... <br> Please wait a minute. Don\'t leave this page while scrapping.</div>');
			}
		})
		.done(function(data) {
			if($.trim(data)!='')
			{
				$(".pt").html('<div class="alert alert-success">Updated Data.</div>');
				location.reload();
			}else{
				$(".pt").html('');
			}
		});
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mrplurbackend\resources\views/top-overall-tracks.blade.php ENDPATH**/ ?>