
        <div class="side-content-wrap">
            <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">
                <ul class="navigation-left">
                    <li class="nav-item">
                        <a class="nav-item-hold" href="<?php echo e(url('youtube')); ?>">
                            <i class="nav-icon i-Youtube"></i>
                            <span class="nav-text">Youtube</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-item-hold" href="<?php echo e(url('tracklist')); ?>">
                            <i class="nav-icon i-Music-Note-2"></i>
                            <span class="nav-text">1001 Tracklist</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-item-hold" href="<?php echo e(url('vksearch')); ?>">
                            <i class="nav-icon i-Folder-Search"></i>
                            <span class="nav-text">VK search</span>
                        </a>
                        <div class="triangle"></div>
                    </li>
                    
                </ul>
            </div>

            <div class="sidebar-left-secondary rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">
                <!-- Submenu Dashboards -->

            </div><?php /**PATH C:\xampp\htdocs\mrplurbackend\resources\views/layout/menu.blade.php ENDPATH**/ ?>