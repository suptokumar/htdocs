<?php $__env->startSection("title",__("mrplurssive admin panel")); ?>
<?php $__env->startSection("page"); ?>
<div class="breadcrumb">
    <h1>MRPLURSSIVE</h1>
    <ul>
        <li><a href="<?php echo e(url('youtube')); ?>">youtube</a></li>
        <li>Overview</li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<iframe src="https://www.vk.com" style="width:100%; height: 500px;"></iframe>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mrplurbackend\resources\views/welcome.blade.php ENDPATH**/ ?>