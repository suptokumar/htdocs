
<?php $__env->startSection("title",__("Most Views Details - mrplurssive admin panel")); ?>
<?php $__env->startSection("page"); ?>
<a href="<?php echo e(url('tracklist')); ?>" class="btn btn-secondary m-1">Most Viewed Tracklist</a>
<a href="<?php echo e(url('mostplayed')); ?>" class="btn btn-secondary m-1">Most Played Tracks</a>
<a href="<?php echo e(url('topnewcomertracks')); ?>" class="btn btn-secondary m-1">Top Newcomer Tracks</a>
<a href="<?php echo e(url('mostviewedtracks-detailed')); ?>" class="btn btn-info m-1" style="color: white;">Most Viewed Tracks (Detailed)</a>
<a href="<?php echo e(url('scrap-single-track')); ?>" class="btn btn-secondary m-1">Scrap Single Track</a>

<br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<a href="<?php echo e(url('detailsload')); ?>" class="btn btn-red" style="color: white;" onclick="loading()">Clear & Reload Data</a>
<script>
	function loading()
	{
		$(".loading").show();
	}
</script>
<div class="loading alert alert-danger" style="display: none">Scrapping...</div>
<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
	$tm = strtotime($el->created_at);
	date_default_timezone_set("Asia/Singapore");
?>
<div class="alert alert-success float-right">Scrapped on:
<?php echo e(date("d M Y, h:i a", $tm)); ?>

</div>
<?php break; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<table class="table custom">
	<tr>
		<th>#</th>
		<th>Downloaded</th>
		<th>Title</th>
		<th>Count</th>
		<th>VK search</th>
				<th>Drive Search</th>

		<th>Spotify search</th>
	</tr>
	<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php
		if ($el->title==' ID  -  ID   ' || $el->title=='') {
			continue;
		}
	?>
		<tr>
			<td><?php echo e($key+1); ?></td>
			<td>
				<?php if($el->downloaded==1): ?>
				<input type="checkbox" checked="checked" onchange="al(<?php echo e($el->id); ?>)">
				<?php else: ?>
				<input type="checkbox" onchange="al(<?php echo e($el->id); ?>)">
				<?php endif; ?>
			</td>
			<td><?php echo e(trim(preg_replace('/\s+/'," ",(str_replace(array("&amp;","&euml;","&eacute;","&Oslash;","&oslash;","&nbsp;"),array("&","e","e","O","o",""),$el->title))))); ?></td>
			<td><?php echo e($el->countse); ?></td>
			<td><a href="https://vk.com/search?c[per_page]=200&c[q]=<?php echo e(urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))); ?>&c[section]=audio" class="btn btn-secondary" target="_blank">VK Search</a></td>
			<td><a href="https://drive.google.com/drive/u/0/search?q=<?php echo e(urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))); ?>" class="btn btn-secondary" target="_blank">Drive Search</a></td>

			<td><a href="https://open.spotify.com/search/<?php echo e($el->title); ?>" class="btn btn-secondary" target="_blank">Spotify Search</a></td>
			
			
			

			

 		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<script>
	function al(id)
	{
		$.ajax({
			url: '<?php echo e(url("/updatedetails")); ?>',
			type: "POST",
			data: {id:id, _token: "<?php echo e(csrf_token()); ?>"},
			success:function(data){
				console.log(data);
			}
		});
	}



</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mrplurbackend\resources\views/mostviewedtracks-detailed.blade.php ENDPATH**/ ?>