
<?php $__env->startSection("title",__("Tracklist - mrplurssive admin panel")); ?>
<?php $__env->startSection("page"); ?>
<a href="<?php echo e(url('tracklist')); ?>" class="btn btn-secondary m-1">Most Viewed Tracklist</a>
<a href="<?php echo e(url('mostplayed')); ?>" class="btn btn-secondary m-1">Most Played Tracks</a>
<a href="<?php echo e(url('topnewcomertracks')); ?>" class="btn btn-secondary m-1">Top Newcomer Tracks</a>
<a href="<?php echo e(url('mostviewedtracks-detailed')); ?>" class="btn btn-secondary m-1">Most Viewed Tracks (Detailed)</a>
<a href="<?php echo e(url('scrap-single-track')); ?>" class="btn btn-info m-1" style="color: white;">Scrap Single Track</a>

<br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="pt"></div>
<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
	$tm = strtotime($el->created_at);
	date_default_timezone_set("Asia/Singapore");
?>
<div class="alert alert-success float-right">Scrapped on:
<?php echo e(date("d M Y, h:i a", $tm)); ?>

</div>
<?php break; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="row">
<div class="col-8">
<input type="text" id="so" placeholder="URL" class="form-control">
</div>
<div class="col-4">
<button class="btn btn-primary" style="color: white" onclick="fetch(this)">Fetch</button>
<button class="btn btn-danger" style="color: white" onclick="clears(this)">Clear</button>
</div>
</div>
<table class="table custom">
	<tr>
		<th>#</th>
		<th>Downloaded</th>
		<th>Title</th>
		<th>DJ support</th>
		<th>VK Search</th>
		<th>Drive Search</th>
		<th>Spotify Search</th>
	</tr>
	<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php
		if ($el->title==' ID  -  ID   ' || $el->title=='') {
			continue;
		}
	?>
		<tr>
			<td><?php echo e($key+1); ?></td>
			<td>
				<?php if($el->downloaded==1): ?>
				<input type="checkbox" checked="checked" onchange="al(<?php echo e($el->id); ?>)">
				<?php else: ?>
				<input type="checkbox" onchange="al(<?php echo e($el->id); ?>)">
				<?php endif; ?>
			</td>
			<td><?php echo e(str_replace(array("&amp;","&euml;","&eacute;","&Oslash;","&oslash;","&nbsp;"),array("&","e","e","O","o",""),$el->title)); ?></td>
			<td><?php echo e($el->dj); ?></td>
			
			<td><a href="https://vk.com/search?c[per_page]=200&c[q]=<?php echo e(urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))); ?>&c[section]=audio" class="btn btn-secondary" target="_blank">VK Search</a></td>
			<td><a href="https://drive.google.com/drive/u/0/search?q=<?php echo e(urlencode(trim(preg_replace('/\s+/'," ",str_replace(array('_','(',')','[',']','{','}','-','&amp;','&Oslash;',"&oslash;","&nbsp;"), array('','','','','','','','','',' ','',''),$el->title))))); ?>" class="btn btn-secondary" target="_blank">Drive Search</a></td>
			
			<td><a href="https://open.spotify.com/search/<?php echo e($el->title); ?>" class="btn btn-secondary" target="_blank">Spotify Search</a></td>


			

 		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<script>
	function al(id)
	{
		$.ajax({
			url: '<?php echo e(url("/updatenewtrack")); ?>',
			type: "POST",
			data: {id:id, _token: "<?php echo e(csrf_token()); ?>"},
			success:function(data){
				console.log(data);
			}
		});
	}

	function fetch(t){
		if($.trim($("#so").val())==''){
			alert("No url Found");
		}else{
			$.ajax({
			url: '<?php echo e(url("/urler")); ?>',
			type: "GET",
			data: {url:$("#so").val(), _token: "<?php echo e(csrf_token()); ?>"},
			beforeSend:function()
			{
				$(t).html("Processing");
			},
			success:function(data){
				console.log(data);
				$(t).html("Reloading");
				location.reload();
			}
		});
		}
	}



	function clears(t)
	{
		$.ajax({
			url: '<?php echo e(url("/clear")); ?>',
			type: "GET",
			data: { _token: "<?php echo e(csrf_token()); ?>"},
			beforeSend:function()
			{
				$(t).html("Processing");
			},
			success:function(data){
				console.log(data);
				$(t).html("Reloading");
				location.reload();
			}
		});
	}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mrplurbackend\resources\views/singletrack.blade.php ENDPATH**/ ?>