
<?php $__env->startSection("title","Books | Classroommoney"); ?>
<?php $__env->startSection("9","active"); ?>
<?php $__env->startSection("content"); ?>

<div class="container">

<div class="all_payments" style="width: 100%">
  
</div>
<div class="section">


<form style="background: white; padding: 20px; width: 90%; margin: 100px auto; border: 1px solid #ccc;" action="<?php echo e(url('/admin/savesettings')); ?>" method="POST" enctype="multipart/form-data">

  <?php echo csrf_field(); ?>
  
  <h2>Settings</h2>
  <hr>

  <?php if($message = session("message")): ?>
  <div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>

<?php if($success = session("success")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>
  <div class="form-row">
<?php
	use App\Http\Controllers\soft;
?>
    <div class="form-group col-md-6">
      <label for="singleamount">Single Payment Amount <span style="color: red">*</span></label>
      <input type="text" class="form-control" required="" value="<?php echo e(soft::set()->single_payment); ?>" id="singleamount" name="singleamount">
    </div>
    </div>
      <div class="form-row">

    <div class="form-group col-md-6">
      <label for="multiplepayment">Multiple  Payment Amount <span style="color: red">*</span></label>
      <input type="text" class="form-control" required="" value="<?php echo e(soft::set()->multi_payment); ?>"  id="multipleamount" name="multipleamount">
    </div>
    </div>
    <button type="submit" class="btn btn-primary">Save</button>

</form>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\classroommoney\resources\views/admin/settings.blade.php ENDPATH**/ ?>