
<?php $__env->startSection("title","Add Waitings | School management software"); ?>
<?php $__env->startSection("active","waitings"); ?>
<?php $__env->startSection("content"); ?>
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
}
</style>
 <article>

<form style="width: 90%; margin: 0 auto;" action="<?php echo e(url('/admin/waitings/add')); ?>" method="POST" enctype="multipart/form-data"><br>
	<h3 style="text-align: center;">Add Waiting Member</h3>
			<?php if($message = session("message")): ?>
	<div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
	<div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>

<?php if($new_client = session("new_client")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($new_client); ?>

</div>
<?php endif; ?>

 <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Student Info')); ?></label>
    <input type="text" class="form-control" id="name" name="name"  value="<?php echo e(old("name")); ?>" required aria-describedby="emailHelp" placeholder="Student Info">
  </div>
<input type="hidden" name="id"  value="<?php echo e(Auth::user()->id); ?>">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Contact Info')); ?></label>
    <input type="text" class="form-control" id="contact" required="" name="contact" aria-describedby="emailHelp"    value="<?php echo e(old("contact")); ?>" placeholder="Contact">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('When to contact')); ?></label>
    <input type="text" class="form-control" id="time_to_contact" required="" name="time_to_contact" aria-describedby="emailHelp"     value="<?php echo e(old("time_to_contact")); ?>" placeholder="Time to contact">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Who is following up')); ?></label>
    <input type="text" class="form-control" id="follower" required="" name="follower" aria-describedby="emailHelp" value="<?php echo e(old("follower")); ?>" placeholder="User">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('How to reach')); ?></label>
    <select class="form-control" id="reach" required="" name="reach">
      <option value="Whatsapp">Whatsapp</option>
      <option value="Facebook">Facebook</option>
      <option value="Ads">Ads</option>
      <option value="Email">Email</option>
      <option value="Others">Others</option>
    </select>
  </div>

  <div style="padding: 10px; overflow: hidden">
  <button type="submit" class="btn btn-success" style="float: right;">Save</button>
  </div>
</form>


 </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/admin/waitings.blade.php ENDPATH**/ ?>