<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent("title"); ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    
    <script src="<?php echo e(asset('/public/js/jquery.js')); ?>"></script>
  
</head>
<body>
  <div class="header">
<header style="background: #f0f0f0" id="bg_no">

<span style="font-size: 25px !important; margin: 10px;float: left;font-weight: bold;text-shadow: 1px 1px 1px #848484;color: #000000;">Classroom Money</span>
<ul class="nav nav-pills justify-content-center">
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("1"); ?>" href="<?php echo e(url('/')); ?>">Admin</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("2"); ?>" href="<?php echo e(url('/admin/teachers')); ?>">Teacher Verifications</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("3"); ?>" href="<?php echo e(url('/admin/withdrawal')); ?>">Withdrawal Requests</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("4"); ?>" href="<?php echo e(url('/admin/live')); ?>">Live</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("6"); ?>" href="<?php echo e(url('/admin/books')); ?>">Add Books</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("7"); ?>" href="<?php echo e(url('/admin/bookrequest')); ?>">Book Request</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("8"); ?>" href="<?php echo e(url('/admin/payments')); ?>">Payments</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("10"); ?>" href="<?php echo e(url('/admin/addquestion')); ?>">Add Questions</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("11"); ?>" href="<?php echo e(url('/admin/userrecords')); ?>">User Records</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("9"); ?>" href="<?php echo e(url('/admin/settings')); ?>">Settings</a>
  </li>
  <li class="nav-item">
    <a class="nav-link <?php echo $__env->yieldContent("5"); ?>" href="<?php echo e(url('/logout')); ?>">Logout</a>
  </li>
</ul>

</header>
<style>
    header#bg_no {
    width: 100%;
    z-index: 1000;
    color: white;
    top: 0;
}
#bg_no a{
    margin: 15px 10px 15px 10px;
}

</style>
  </div>

	<style>
  .<?php echo $__env->yieldContent("active"); ?>{
    background: black;
  }
</style>

<?php echo $__env->yieldContent("content"); ?>

   


	<script src="<?php echo e(asset('/public/js/dash.js?'.rand())); ?>"></script>
  <script src="<?php echo e(asset('/public/js/main.js?'.rand())); ?>"></script>

  <?php echo $__env->yieldContent("script"); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\classroommoney\resources\views/layout/app.blade.php ENDPATH**/ ?>