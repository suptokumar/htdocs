
<?php $__env->startSection("title","Add Questions | Classroommoney"); ?>
<?php $__env->startSection("10","active"); ?>
<?php $__env->startSection("content"); ?>

<div class="container">

<div class="section">

  <h2>Add Questions</h2>
  <div class="all_payments">
    
<form action="<?php echo e(url('/admin/savequestions')); ?>" method="POST">
  <?php echo csrf_field(); ?>
        <?php if($message = session("message")): ?>
  <div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>

<?php if($new_client = session("new_client")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($new_client); ?>

</div>
<?php endif; ?>
  <div class="row">
    <div class="col-12">
      <label for="question">Question</label>
      <input type="text" name="question" value="<?php echo e($books->question); ?>" id="question" class="form-control">
    </div>
  </div>

  <div class="row">
    <div class="col-6">
      <label for="opt1">A.</label>
      <input type="text"  name="opt1" id="opt1" value="<?php echo e($books->opt1); ?>" class="form-control">
    </div>
    <div class="col-6">
      <label for="opt2">B.</label>
      <input type="text"  name="opt2" id="opt2" value="<?php echo e($books->opt2); ?>" class="form-control">
    </div>
  </div>

  <div class="row">
    <div class="col-6">
      <label for="opt3">C.</label>
      <input type="text"  name="opt3" id="opt3" value="<?php echo e($books->opt3); ?>" class="form-control">
    </div>
    <div class="col-6">
      <label for="opt4">D.</label>
      <input type="text"  name="opt4" id="opt4" value="<?php echo e($books->opt4); ?>" class="form-control">
    </div>
  </div>


  <div class="row">
    <div class="col-8">
      <label for="correct">Correct</label>
      <select name="correct" id="correct" class="form-control">
        <option value="opt1" <?php echo e($books->correct=='opt1'?'selected':''); ?>>opt1</option>
        <option value="opt2" <?php echo e($books->correct=='opt2'?'selected':''); ?>>opt2</option>
        <option value="opt3" <?php echo e($books->correct=='opt3'?'selected':''); ?>>opt3</option>
        <option value="opt4" <?php echo e($books->correct=='opt4'?'selected':''); ?>>opt4</option>
      </select>
    </div>
    <div class="col-4">
      <br>
      <input type="hidden" value="<?php echo e($books->id); ?>" name="book">
      <input type="submit"  name="submit" id="submit" value="Save" class="btn btn-success mt-2">
    </div>
  </div>


<?php
  use App\Models\question;
  $questionlist = question::where("book","=",$books->book)->get();
?>
  
<table class="table">
      <tr>
        <th>Question</th>
        <th>Opt1</th>
        <th>Opt2</th>
        <th>Opt3</th>
        <th>Opt4</th>
        <th>Correct</th>
        <th>View</th>
        <th>Options</th>
      </tr>
      <?php $__currentLoopData = $questionlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr id="bcmc<?php echo e($q->id); ?>">
        <td><?php echo e($q->question); ?></td>
        <td><?php echo e($q->opt1); ?></td>
        <td><?php echo e($q->opt2); ?></td>
        <td><?php echo e($q->opt3); ?></td>
        <td><?php echo e($q->opt4); ?></td>
        <td><?php echo e($q->correct); ?></td>
        <td>Answer Time: <?php echo e($q->showtime); ?><br>Average %: <?php echo e($q->corper); ?></td>
        <td><a href="<?php echo e(url('/admin/question/edit/'.$q->id)); ?>" class="btn btn-success">Edit</a><a href="javascript:void(0)" class="btn btn-danger" onclick="deleteit(<?php echo e($q->id); ?>,this)">Delete</a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>



</form>


  </div>
</div>
<script>
  function deleteit(id,t){

      $.ajax({
        url: "<?php echo e(url('/admin/deletequestion')); ?>",
        type: 'POST',
        data: {id: id,_token: '<?php echo e(csrf_token()); ?>'},
      })
      .done(function(data) {
        $("#bcmc"+id).css('background',"#F4FCFF");
        $("#bcmc"+id).fadeOut();
      })
      .fail(function() {
        $("#bcmc"+id).css('background',"#FFCCCC");
      })
      .always(function() {
        console.log("complete");
      });

}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\classroommoney\resources\views/admin/questionsedit.blade.php ENDPATH**/ ?>