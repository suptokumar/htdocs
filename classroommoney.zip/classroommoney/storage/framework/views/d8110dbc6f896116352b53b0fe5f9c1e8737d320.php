
<?php $__env->startSection("title","Create Client | School management software"); ?>
<?php $__env->startSection("active","settings"); ?>
<?php $__env->startSection("content"); ?>
<style>
.page-content .grid > article{
  grid-column: 1 / -1 !important;
    margin-top: 60px;
flex-direction: column;
}
</style>
 <article>

<form style="width: 90%; margin: 0 auto;" action="<?php echo e(url('/reqs_d')); ?>" method="POST" enctype="multipart/form-data"><br>
	<h3 style="text-align: center;">Cancel Class</h3>
			<?php if($message = session("message")): ?>
	<div class="alert alert-danger" role="alert">
  <?php echo e($message); ?>

</div>
<?php endif; ?>
<?php if($success = session("success")): ?>
	<div class="alert alert-success" role="alert">
  <?php echo e($success); ?>

</div>
<?php endif; ?>

<?php if($new_client = session("new_client")): ?>
  <div class="alert alert-success" role="alert">
  <?php echo e($new_client); ?>

</div>
<?php endif; ?>

  <div class="form-group">
    <label for="exampleInputEmail1"><?php echo e(__('Write Note')); ?></label>
    <div style="position: relative;">
    <textarea class="form-control" id="note" name="note" aria-describedby="emailHelp"></textarea>
    </div>
  </div>
<?php echo csrf_field(); ?>


 <input type="hidden" name="del" value="<?php echo e($id); ?>">
  <div style="padding: 10px; overflow: hidden">
  <button type="submit" class="btn btn-success" style="float: right;">Request Now</button>
  </div>
</form>


 </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/request_cancel.blade.php ENDPATH**/ ?>